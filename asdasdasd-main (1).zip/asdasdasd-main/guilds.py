"""
╔══════════════════════════════════════════════════════════════════════╗
║        🌸 SUNSHINE PARADISE — GUILDS + ECONOMY  v4.0  🌸            ║
╠══════════════════════════════════════════════════════════════════════╣
║  Подключение в main.py:                                              ║
║      from guilds import setup                                        ║
║      setup(bot)                                                      ║
╚══════════════════════════════════════════════════════════════════════╝

  Что внутри:
  ● Экономика (XP + монеты за сообщения, уровни, daily, work, pay, top)
  ● 300 сообщений до запуска бота — условие для !gcreate
  ● Гильдии с ЛС диалогом создания
  ● Каналы по шаблону ——・КЛАН / ┏【emoji】канал / ┃... / ┖...
  ● Цветные эмодзи в каналах под выбранный цвет гильдии
  ● Полный набор команд управления + войны
  ● 15 админских команд
  ● Ивент Конец Зимы / Начало Весны с авто-анонсом
  ● JSON база данных (без MongoDB)
  ● Components V1 (custom_id без disnake.ui.View)

  Исправленные баги v4.0:
  ● Components V1 вместо ui.View (InviteView, ListPages, SeasonView)
  ● tuple[...] → Tuple[...] для совместимости с Python 3.8
  ● on_command_error не перехватывает ошибки чужих когов
  ● season_task не дублирует анонс при рестарте
  ● MSG_REQUIRED хранится в settings DB, не только в памяти
  ● rebuild атомарно сохраняет изменённый gdata
  ● creation_dialog валидирует тег на alnum
  ● gpatrol проверял не тот сезонный id
  ● Пагинация: кнопки работают для любого пользователя корректно
"""

import disnake
from disnake.ext import commands, tasks
import json, os, asyncio, random, uuid
from datetime import datetime, timedelta
from typing import Optional, List, Tuple
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from dotenv import load_dotenv

load_dotenv()

# ══════════════════════════════════════════════════════════════
#   🗄️  MONGODB ИНИЦИАЛИЗАЦИЯ (СИНХРОННАЯ)
# ══════════════════════════════════════════════════════════════

MONGO_URI = os.getenv("MONGODB_URI", "mongodb+srv://user:pass@cluster.mongodb.net/sunshine")
mongo_client = None
db = None

def init_db():
    """Инициализировать MongoDB подключение"""
    global mongo_client, db
    try:
        mongo_client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        db = mongo_client.get_database()
        # Проверяем подключение
        db.command("ping")
        print("✅ MongoDB подключена успешно")
        
        # Создаем индексы для оптимизации
        db["users"].create_index([("server_id", 1), ("user_id", 1)], unique=True)
        db["guilds"].create_index([("server_id", 1), ("id", 1)], unique=True)
        return True
    except Exception as e:
        print(f"❌ Ошибка подключения к MongoDB: {e}")
        # Создаем заглушку для db, чтобы избежать NameError, если база не подключена
        class MockDB:
            def __getitem__(self, name):
                return self
            def find_one(self, *args, **kwargs): return None
            def find(self, *args, **kwargs): return []
            def update_one(self, *args, **kwargs): return None
            def insert_one(self, *args, **kwargs): return None
            def count_documents(self, *args, **kwargs): return 0
            def create_index(self, *args, **kwargs): return None
            def command(self, *args, **kwargs): return None
            def __call__(self, *args, **kwargs): return self
        db = MockDB()
        return False

def close_db():
    """Закрыть MongoDB подключение"""
    global mongo_client
    if mongo_client:
        mongo_client.close()
        print("🔌 MongoDB подключение закрыто")

# ══════════════════════════════════════════════════════════════
#   ⚙️  КОНФИГУРАЦИЯ
# ══════════════════════════════════════════════════════════════

EMBED_AUTHOR = "🌸 Sunshine Paradise 🌸"

# ── Экономика ─────────────────────────────────────────────────
XP_PER_MSG        = 10
COINS_PER_MSG     = 2
XP_COOLDOWN_SEC   = 10
DAILY_COINS       = 200
DAILY_COOLDOWN_H  = 20
WORK_COOLDOWN_MIN = 45
DEFAULT_MSG_REQUIRED = 300   # значение по умолчанию; реальное хранится в DB

# ── ⏱️ ЗАЩИТА ОТ RATE LIMIT - COOLDOWNS ДЛЯ АКТИВНОГО СЕРВЕРА ──
# Увеличенные значения для предотвращения рейт лимитов от Discord API
COOLDOWNS = {
    # Легкие команды (информация)
    "info_light": (1, 8),           # !profile, !balance, !ginfo, !glist
    
    # Средние команды (изменение данных)
    "eco_medium": (1, 15),          # !daily, !work, !pay, !gcolor, !gdesc
    
    # Тяжелые команды (создание/удаление объектов)
    "guild_heavy": (1, 20),         # !gcreate, !gdelete, !ginvite, !gleave
    
    # Очень тяжелые команды (большие изменения)
    "super_heavy": (1, 30),         # !gtransfer, !rebuild
    
    # Ранговые операции
    "rank_ops": (1, 15),            # !gpromote, !gdemote
    
    # Войны и конфликты (долгие операции)
    "wars": (1, 60),                # !gwar, !gpatrol
}


# ── Уровни ────────────────────────────────────────────────────
LEVELS = {
     1:      0,  2:    300,  3:    700,  4:   1300,  5:   2100,
     6:   3100,  7:   4300,  8:   5700,  9:   7300, 10:   9100,
    11:  11200, 12:  13600, 13:  16300, 14:  19300, 15:  22700,
    16:  26500, 17:  30700, 18:  35300, 19:  40300, 20:  45700,
}
MAX_LEVEL = 20

# ── Гильдии ───────────────────────────────────────────────────
BASE_MEMBERS = 10

# ── СИСТЕМА РАНГОВ С ПРИВИЛЕГИЯМИ ─────────────────────────────
GUILD_RANKS = {
    "owner": {
        "name": "Основатель",
        "icon": "👑",
        "color": 0xFFD700,
        "xp_bonus": 1.5,
        "coin_bonus": 1.5,
        "can_invite": True,
        "can_kick": True,
        "can_promote": True,
        "can_edit_settings": True,
        "can_manage_vault": True,
        "can_delete_guild": True,
        "priority": 5,
    },
    "viceowner": {
        "name": "Вице-лидер",
        "icon": "💎",
        "color": 0xDCC0DE,
        "xp_bonus": 1.3,
        "coin_bonus": 1.3,
        "can_invite": True,
        "can_kick": True,
        "can_promote": True,
        "can_edit_settings": False,
        "can_manage_vault": True,
        "can_delete_guild": False,
        "priority": 4,
    },
    "officer": {
        "name": "Офицер",
        "icon": "🛡️",
        "color": 0xC0FFEE,
        "xp_bonus": 1.15,
        "coin_bonus": 1.15,
        "can_invite": True,
        "can_kick": True,
        "can_promote": False,
        "can_edit_settings": False,
        "can_manage_vault": True,
        "can_delete_guild": False,
        "priority": 3,
    },
    "moderator": {
        "name": "лейтенант",
        "icon": "🔨",
        "color": 0x9370DB,
        "xp_bonus": 1.1,
        "coin_bonus": 1.1,
        "can_invite": True,
        "can_kick": False,
        "can_promote": False,
        "can_edit_settings": False,
        "can_manage_vault": False,
        "can_delete_guild": False,
        "priority": 2,
    },
    "member": {
        "name": "Участник",
        "icon": "👤",
        "color": 0x808080,
        "xp_bonus": 1.0,
        "coin_bonus": 1.0,
        "can_invite": False,
        "can_kick": False,
        "can_promote": False,
        "can_edit_settings": False,
        "can_manage_vault": False,
        "can_delete_guild": False,
        "priority": 1,
    },
    "recruit": {
        "name": "Новобранец",
        "icon": "🌱",
        "color": 0x90EE90,
        "xp_bonus": 0.8,
        "coin_bonus": 0.8,
        "can_invite": False,
        "can_kick": False,
        "can_promote": False,
        "can_edit_settings": False,
        "can_manage_vault": False,
        "can_delete_guild": False,
        "priority": 0,
    },
}

GUILD_UPGRADES = {
    "slot_1":   {"price":  2_000, "members": 5,  "emoji": "👥", "name": "Слот I"},
    "slot_2":   {"price":  6_000, "members": 10, "emoji": "👥", "name": "Слот II"},
    "slot_3":   {"price": 15_000, "members": 20, "emoji": "👥", "name": "Слот III"},
    "vault_1":  {"price":  3_000, "members": 0,  "emoji": "💰", "name": "Казна I"},
    "vault_2":  {"price":  9_000, "members": 0,  "emoji": "💰", "name": "Казна II"},
    "prestige": {"price": 25_000, "members": 0,  "emoji": "⭐", "name": "Престиж"},
}

# ── Цвета + эмодзи каналов ────────────────────────────────────
COLORS = {
    "blue":   {"label": "🔵 Синий",      "hex": 0x3498DB,
               "cat": "🔵", "ch": ["🔹","🔷","💎","🫐","🌀","🧿"]},
    "red":    {"label": "🔴 Красный",    "hex": 0xE74C3C,
               "cat": "🔴", "ch": ["❤️","🌹","🍎","🔸","💢","🎯"]},
    "green":  {"label": "🟢 Зелёный",   "hex": 0x2ECC71,
               "cat": "🟢", "ch": ["🍀","🌿","🌱","🌲","🥝","🌾"]},
    "gold":   {"label": "🟡 Золотой",   "hex": 0xF1C40F,
               "cat": "🟡", "ch": ["⭐","✨","🌟","💛","🏅","🎖️"]},
    "purple": {"label": "🟣 Фиолетовый","hex": 0x9B59B6,
               "cat": "🟣", "ch": ["💜","🔮","🌌","🦄","🪄","🫂"]},
    "pink":   {"label": "🩷 Розовый",   "hex": 0xFF69B4,
               "cat": "🩷", "ch": ["🌸","🌷","🌺","🎀","🍬","💅"]},
    "white":  {"label": "⚪ Белый",     "hex": 0xDDDDDD,
               "cat": "⚪", "ch": ["🤍","🕊️","❄️","🌙","🫧","🌫️"]},
    "orange": {"label": "🟠 Оранжевый","hex": 0xE67E22,
               "cat": "🟠", "ch": ["🍊","🔶","🦊","🌅","🔥","🎃"]},
    "aqua":   {"label": "🩵 Голубой",   "hex": 0x1ABC9C,
               "cat": "🩵", "ch": ["🩵","🌊","🐬","🐟","💧","🫧"]},
}
DEFAULT_COLOR = "blue"

# ── Шаблон каналов ────────────────────────────────────────────
CHANNEL_TPL = [
    {"slug": "анонсы",   "type": "text",  "readonly": True,  "officers_only": False, "topic": "Официальные новости гильдии"},
    {"slug": "правила",  "type": "text",  "readonly": True,  "officers_only": False, "topic": "Правила и устав гильдии"},
    {"slug": "чат",      "type": "text",  "readonly": False, "officers_only": False, "topic": "Общение участников"},
    {"slug": "офицеры",  "type": "text",  "readonly": False, "officers_only": True,  "topic": "Канал офицеров"},
    {"slug": "трибуна",  "type": "voice", "readonly": False, "officers_only": False, "topic": ""},
]

# ── Ивент ─────────────────────────────────────────────────────
SEASON_CH_KEY = "event_channel_id"

WINTER_TASKS = [
    {"id": "wt_snow",   "emoji": "❄️", "name": "Снежки",       "goal": 10, "reward": 300, "desc": "Кинь снежок 10 раз (!snowball)"},
    {"id": "wt_warm",   "emoji": "🔥", "name": "Согрей друга", "goal": 5,  "reward": 200, "desc": "Согрей 5 друзей (!warm @юзер)"},
    {"id": "wt_man",    "emoji": "⛄", "name": "Снеговик",     "goal": 1,  "reward": 500, "desc": "Слепи снеговика (!snowman)"},
    {"id": "wt_patrol", "emoji": "🛡️", "name": "Патруль",      "goal": 3,  "reward": 400, "desc": "Защити гильдию (!gpatrol)"},
]
SPRING_TASKS = [
    {"id": "sp_flower", "emoji": "🌸", "name": "Цветы",    "goal": 15, "reward": 350, "desc": "Собери цветы 15 раз (!flower)"},
    {"id": "sp_plant",  "emoji": "🌱", "name": "Посадка",  "goal": 5,  "reward": 250, "desc": "Посади цветок другу (!plant @юзер)"},
    {"id": "sp_rain",   "emoji": "🌧️", "name": "Дождь",    "goal": 1,  "reward": 600, "desc": "Призови дождь (!spring_rain)"},
    {"id": "sp_bloom",  "emoji": "🌺", "name": "Цветение", "goal": 5,  "reward": 500, "desc": "Учавствуй в делах гильдии"},
]


# ══════════════════════════════════════════════════════════════
#   💾  БАЗА ДАННЫХ - MONGODB (СИНХРОННАЯ ВЕРСИЯ)
# ══════════════════════════════════════════════════════════════

def _udef() -> dict:
    """Значения по умолчанию для пользователя"""
    return {
        "xp": 0, "level": 1, "coins": 0, "messages": 0,
        "guild_id": None, "guild_rank": None,
        "last_xp": None, "daily_last": None, "work_last": None,
        "event_progress": {}, "event_claimed": [],
    }

def _dump(data=None):
    """Заглушка для совместимости со старым кодом"""
    pass

def get_user(uid: str, sid: str) -> dict:
    """Получить пользователя из MongoDB"""
    try:
        doc = db["users"].find_one({"user_id": uid, "server_id": sid})
        if not doc:
            new_user = {"user_id": uid, "server_id": sid, **_udef()}
            db["users"].insert_one(new_user)
            return new_user
        return dict(doc)
    except Exception as e:
        print(f"❌ Ошибка получения пользователя: {e}")
        return _udef()

def save_user(uid: str, sid: str, patch: dict):
    """Сохранить/обновить пользователя в MongoDB"""
    try:
        db["users"].update_one(
            {"user_id": uid, "server_id": sid},
            {"$set": patch},
            upsert=True
        )
    except Exception as e:
        print(f"❌ Ошибка сохранения пользователя: {e}")

def get_settings(sid: str) -> dict:
    """Получить настройки сервера"""
    try:
        doc = db["settings"].find_one({"server_id": sid})
        return dict(doc) if doc else {"server_id": sid}
    except Exception as e:
        print(f"❌ Ошибка получения настроек: {e}")
        return {}

def save_settings(sid: str, patch: dict):
    """Сохранить настройки сервера"""
    try:
        db["settings"].update_one(
            {"server_id": sid},
            {"$set": patch},
            upsert=True
        )
    except Exception as e:
        print(f"❌ Ошибка сохранения настроек: {e}")

def get_msg_required(sid: str) -> int:
    """Получить требуемое кол-во сообщений для создания гильдии"""
    settings = get_settings(sid)
    return settings.get("msg_required", DEFAULT_MSG_REQUIRED)

def get_guild(gid: str) -> Optional[dict]:
    """Получить гильдию по ID"""
    try:
        doc = db["guilds"].find_one({"id": gid})
        return dict(doc) if doc else None
    except Exception as e:
        print(f"❌ Ошибка получения гильдии: {e}")
        return None

def save_guild(gid: str, patch: dict):
    """Сохранить гильдию"""
    try:
        db["guilds"].update_one(
            {"id": gid},
            {"$set": patch},
            upsert=True
        )
    except Exception as e:
        print(f"❌ Ошибка сохранения гильдии: {e}")

def guild_by_tag(sid: str, tag: str) -> Optional[dict]:
    """Найти гильдию по тегу"""
    try:
        return db["guilds"].find_one({
            "server_id": sid,
            "tag": tag.upper()
        })
    except Exception as e:
        print(f"❌ Ошибка поиска гильдии: {e}")
        return None

def guild_members(gid: str, sid: str) -> List[dict]:
    """Получить членов гильдии"""
    try:
        members = list(db["users"].find({
            "server_id": sid,
            "guild_id": gid
        }))
        return members
    except Exception as e:
        print(f"❌ Ошибка получения членов гильдии: {e}")
        return []

def member_count(gid: str, sid: str) -> int:
    """Получить количество членов гильдии"""
    try:
        count = db["users"].count_documents({
            "server_id": sid,
            "guild_id": gid
        })
        return count
    except Exception as e:
        print(f"❌ Ошибка подсчета членов: {e}")
        return 0

def member_limit(upgrades: list) -> int:
    """Вычислить лимит членов гильдии"""
    base = BASE_MEMBERS
    for k in upgrades:
        upg = GUILD_UPGRADES.get(k)
        if upg:
            base += upg["members"]
    return base

def calc_level(xp: int) -> int:
    """Вычислить уровень по XP"""
    lvl = 1
    for lv, req in LEVELS.items():
        if xp >= req:
            lvl = lv
    return min(lvl, MAX_LEVEL)

def xp_needed(xp: int, lvl: int) -> int:
    """Получить XP нужный для следующего уровня"""
    nxt = lvl + 1
    return 0 if nxt > MAX_LEVEL else LEVELS[nxt] - xp

# ── Синхронные обертки для работы в контексте commands.Cog ──
# Эти функции вызывают async функции через событийный цикл





# ══════════════════════════════════════════════════════════════
#   🎨  УТИЛИТЫ
# ══════════════════════════════════════════════════════════════

def chex(color: str) -> int:
    return COLORS.get(color, COLORS[DEFAULT_COLOR])["hex"]

def ch_emojis(color: str) -> List[str]:
    return COLORS.get(color, COLORS[DEFAULT_COLOR])["ch"]

def cat_em(color: str) -> str:
    return COLORS.get(color, COLORS[DEFAULT_COLOR])["cat"]

def rank_icon(rank: str) -> str:
    """Получить иконку ранга с поддержкой расширенной системы"""
    return GUILD_RANKS.get(rank, GUILD_RANKS.get("member", {})).get("icon", "👤")

def rank_name(rank: str) -> str:
    """Получить название ранга"""
    return GUILD_RANKS.get(rank, GUILD_RANKS.get("member", {})).get("name", "Участник")

def rank_color(rank: str) -> int:
    """Получить цвет ранга"""
    return GUILD_RANKS.get(rank, GUILD_RANKS.get("member", {})).get("color", 0x808080)

def get_ranks_with_privilege(privilege: str) -> list:
    """Получить все ранги с определенной привилегией"""
    return [r for r, data in GUILD_RANKS.items() if data.get(f"can_{privilege}", False)]

def has_privilege(rank: str, privilege: str) -> bool:
    """Проверить есть ли у ранга привилегия"""
    rank_data = GUILD_RANKS.get(rank, GUILD_RANKS.get("member", {}))
    return rank_data.get(f"can_{privilege}", False)

def pbar(cur: int, goal: int, n: int = 10) -> str:
    f = int(min(cur, goal) / max(goal, 1) * n)
    return "█" * f + "░" * (n - f)

def ce(title: str, desc: str, srv: disnake.Guild, color: int = 0xFF69B4) -> disnake.Embed:
    e = disnake.Embed(title=title, description=desc, color=color)
    e.set_author(name=EMBED_AUTHOR, icon_url=srv.icon.url if srv.icon else None)
    e.timestamp = datetime.utcnow()
    return e

def ge(title: str, desc: str, gdata: dict, srv: disnake.Guild) -> disnake.Embed:
    return ce(title, desc, srv, chex(gdata.get("color", DEFAULT_COLOR)))

# ── Компоненты V1: билдеры ────────────────────────────────────

def invite_row(gid: str, inviter_id: int, invited_id: int) -> disnake.ui.ActionRow:
    return disnake.ui.ActionRow(
        disnake.ui.Button(
            label="✅ Принять",
            style=disnake.ButtonStyle.success,
            custom_id=f"invite:accept:{gid}:{inviter_id}:{invited_id}",
        ),
        disnake.ui.Button(
            label="❌ Отклонить",
            style=disnake.ButtonStyle.danger,
            custom_id=f"invite:decline:{gid}:{inviter_id}:{invited_id}",
        ),
    )

def page_row(owner_id: int, page: int, total: int, key: str) -> disnake.ui.ActionRow:
    return disnake.ui.ActionRow(
        disnake.ui.Button(
            label="◀️",
            style=disnake.ButtonStyle.secondary,
            custom_id=f"page:prev:{owner_id}:{page}:{total}:{key}",
            disabled=page == 0,
        ),
        disnake.ui.Button(
            label="▶️",
            style=disnake.ButtonStyle.secondary,
            custom_id=f"page:next:{owner_id}:{page}:{total}:{key}",
            disabled=page >= total - 1,
        ),
    )

def season_claim_row(uid: int, season: str) -> disnake.ui.ActionRow:
    return disnake.ui.ActionRow(
        disnake.ui.Button(
            label="📬 Забрать награды",
            style=disnake.ButtonStyle.success,
            custom_id=f"season:claim:{uid}:{season}",
        )
    )

def disabled_row(*labels_and_styles) -> disnake.ui.ActionRow:
    """Возвращает строку с задизейбленными кнопками. Каждый custom_id уникален."""
    btns = []
    for idx, (label, style) in enumerate(labels_and_styles):
        btns.append(disnake.ui.Button(
            label=label, style=style,
            custom_id=f"disabled_noop_{idx}_{random.randint(0, 999999)}",
            disabled=True,
        ))
    return disnake.ui.ActionRow(*btns)


# ══════════════════════════════════════════════════════════════
#   🏗️  СТРОИМ КАНАЛЫ ГИЛЬДИИ
# ══════════════════════════════════════════════════════════════

async def build_channels(
    srv: disnake.Guild,
    name: str,
    tag: str,
    color: str,
    owner: disnake.Member,
) -> Tuple[Optional[disnake.CategoryChannel], list]:
    emojis   = ch_emojis(color)
    n        = len(CHANNEL_TPL)
    cat_name = f"——・{name.upper()}"

    cat_ow = {
        srv.default_role: disnake.PermissionOverwrite(read_messages=False, connect=False),
        srv.me:           disnake.PermissionOverwrite(read_messages=True, manage_channels=True,
                                                       manage_permissions=True, connect=True),
        owner:            disnake.PermissionOverwrite(read_messages=True, send_messages=True,
                                                       connect=True, manage_messages=True),
    }
    try:
        cat = await srv.create_category(cat_name, overwrites=cat_ow)
    except disnake.Forbidden:
        return None, []

    created = []
    for i, tpl in enumerate(CHANNEL_TPL):
        border = "┏" if i == 0 else ("┖" if i == n - 1 else "┃")
        em     = emojis[i % len(emojis)]
        cname  = f"{border}【{em}】{tpl['slug']}"

        ow = {
            srv.default_role: disnake.PermissionOverwrite(read_messages=False, connect=False),
            srv.me:           disnake.PermissionOverwrite(read_messages=True, send_messages=True, connect=True),
            owner:            disnake.PermissionOverwrite(read_messages=True, send_messages=True, connect=True),
        }

        try:
            if tpl["type"] == "voice":
                obj = await srv.create_voice_channel(cname, category=cat, overwrites=ow)
            else:
                obj = await srv.create_text_channel(
                    cname, category=cat,
                    topic=tpl.get("topic", ""),
                    overwrites=ow,
                )
                if tpl["readonly"]:
                    # Обычные участники — только чтение
                    await obj.set_permissions(srv.default_role, read_messages=False, send_messages=False)
                    # Лидер — полный доступ
                    await obj.set_permissions(owner, read_messages=True, send_messages=True, manage_messages=True)

            created.append({"id": obj.id, "slug": tpl["slug"], "type": tpl["type"]})
        except Exception as ex:
            print(f"[GUILDS] Канал {tpl['slug']}: {ex}")

    return cat, created


async def refresh_access(srv: disnake.Guild, gdata: dict, member: disnake.Member, remove: bool = False):
    cat_id = gdata.get("category_id")
    if not cat_id:
        return
    cat = srv.get_channel(int(cat_id))
    if not cat:
        return

    user_data = get_user(str(member.id), str(srv.id))
    rank = user_data.get("guild_rank", "member")
    
    # Получаем ранги с привилегией "manage_vault" (офицеры и выше)
    privileged_ranks = get_ranks_with_privilege("manage_vault")

    for ch in cat.channels:
        slug = next((c["slug"] for c in gdata.get("channels", []) if c.get("id") == ch.id), "")
        tpl  = next((t for t in CHANNEL_TPL if t["slug"] == slug), None)
        try:
            if remove:
                await ch.set_permissions(member, overwrite=None)
            # officers_only каналы доступны для привилегированных рангов
            elif tpl and tpl.get("officers_only") and rank not in privileged_ranks:
                await ch.set_permissions(member, read_messages=False)
            else:
                if isinstance(ch, disnake.VoiceChannel):
                    await ch.set_permissions(member, read_messages=True, connect=True)
                else:
                    # readonly-каналы: писать могут привилегированные ранги
                    is_readonly = tpl.get("readonly", False) if tpl else False
                    can_write   = (not is_readonly) or has_privilege(rank, "manage_vault")
                    can_manage  = has_privilege(rank, "manage_vault")
                    await ch.set_permissions(
                        member,
                        read_messages=True,
                        send_messages=can_write,
                        manage_messages=can_manage,
                    )
        except Exception:
            pass


async def rebuild(srv: disnake.Guild, gdata: dict, owner: disnake.Member):
    """Полностью пересоздаёт каналы и атомарно сохраняет gdata в DB."""
    cat_id = gdata.get("category_id")
    if cat_id:
        old = srv.get_channel(int(cat_id))
        if old:
            for ch in list(old.channels):
                try:
                    await ch.delete()
                except Exception:
                    pass
            try:
                await old.delete()
            except Exception:
                pass

    cat, chs = await build_channels(srv, gdata["name"], gdata["tag"], gdata["color"], owner)
    gdata["category_id"] = cat.id if cat else None
    gdata["channels"]    = chs

    # Сохраняем обновленные данные в MongoDB
    gdata["server_id"] = str(srv.id)
    save_guild(gdata["id"], gdata)

    sid = str(srv.id)
    members = guild_members(gdata["id"], sid)
    for m in members:
        mo = srv.get_member(int(m.get("user_id")))
        if mo:
            await refresh_access(srv, gdata, mo)


# ══════════════════════════════════════════════════════════════
#   💬  ЛС ДИАЛОГ СОЗДАНИЯ ГИЛЬДИИ
# ══════════════════════════════════════════════════════════════

async def creation_dialog(ctx: commands.Context, bot: commands.Bot) -> Optional[dict]:
    author = ctx.author

    def dmcheck(m):
        return m.author.id == author.id and isinstance(m.channel, disnake.DMChannel)

    try:
        dm = await author.create_dm()
        await dm.send(embed=disnake.Embed(
            title="🌸 Создание Гильдии — Sunshine Paradise",
            description=(
                "> Привет! Следуй шагам, чтобы создать гильдию.\n"
                "> _ _\n"
                "> На каждый шаг **60 секунд**.\n"
                "> Напиши `отмена` чтобы прервать.\n"
                "> _ _\n"
                "> **Шаг 1 / 4 ·** Введи **название** гильдии (2–30 символов):"
            ), color=0xFF69B4
        ).set_author(name=EMBED_AUTHOR))
    except disnake.Forbidden:
        await ctx.send(embed=ce("Ошибка",
            "> **❌ Не могу написать в ЛС!**\n> Разреши личные сообщения от участников сервера.",
            ctx.guild, 0xFF0000))
        return None

    await ctx.send(embed=ce("🌸 Создание Гильдии", f"> {author.mention}, проверь **личные сообщения** 📬", ctx.guild))

    # ШАГ 1 — Название
    try:
        m = await bot.wait_for("message", check=dmcheck, timeout=60)
    except asyncio.TimeoutError:
        await dm.send("⏰ Время вышло.")
        return None
    if m.content.lower() == "отмена":
        await dm.send("❌ Отменено.")
        return None
    name = m.content.strip()
    if not 2 <= len(name) <= 30:
        await dm.send("❌ Название: 2–30 символов. Отменено.")
        return None

    # ШАГ 2 — Тег
    await dm.send(embed=disnake.Embed(
        title="🌸 Шаг 2 / 4 · Тег",
        description=(
            f"> ✅ Название: **{name}**\n> _ _\n"
            "> Введи **тег** гильдии (2–5 букв/цифр латиницей):\n"
            "> Пример: `SP` `SUNP` `GP1`\n"
            "> В нике будет: `[SP] Имя`"
        ), color=0xFF69B4
    ).set_author(name=EMBED_AUTHOR))

    try:
        m = await bot.wait_for("message", check=dmcheck, timeout=60)
    except asyncio.TimeoutError:
        await dm.send("⏰ Время вышло.")
        return None
    if m.content.lower() == "отмена":
        await dm.send("❌ Отменено.")
        return None
    tag = m.content.strip().upper()
    # Исправленная валидация: только ASCII alnum
    if not (2 <= len(tag) <= 5 and tag.isascii() and tag.isalnum()):
        await dm.send("❌ Тег: 2–5 латинских букв/цифр (например `SP`, `GP1`). Отменено.")
        return None

    # ШАГ 3 — Описание
    await dm.send(embed=disnake.Embed(
        title="🌸 Шаг 3 / 4 · Описание",
        description=(
            f"> ✅ Название: **{name}**\n"
            f"> ✅ Тег: **[{tag}]**\n> _ _\n"
            "> Введи **описание** (до 100 символов)\n"
            "> или напиши `пропустить`:"
        ), color=0xFF69B4
    ).set_author(name=EMBED_AUTHOR))

    try:
        m = await bot.wait_for("message", check=dmcheck, timeout=60)
    except asyncio.TimeoutError:
        await dm.send("⏰ Время вышло.")
        return None
    if m.content.lower() == "отмена":
        await dm.send("❌ Отменено.")
        return None
    desc = "Нет описания" if m.content.lower() == "пропустить" else m.content.strip()[:100]

    # ШАГ 4 — Цвет
    colors_line = " | ".join(f"`{k}` {v['label']}" for k, v in COLORS.items())
    await dm.send(embed=disnake.Embed(
        title="🌸 Шаг 4 / 4 · Цвет",
        description=(
            f"> ✅ Название: **{name}**\n"
            f"> ✅ Тег: **[{tag}]**\n"
            f"> ✅ Описание: _{desc}_\n> _ _\n"
            f"> Напиши **цвет** оформления:\n"
            f"> {colors_line}"
        ), color=0xFF69B4
    ).set_author(name=EMBED_AUTHOR))

    color = DEFAULT_COLOR
    try:
        m = await bot.wait_for("message", check=dmcheck, timeout=60)
        if m.content.lower() == "отмена":
            await dm.send("❌ Отменено.")
            return None
        inp = m.content.strip().lower()
        if inp in COLORS:
            color = inp
        else:
            await dm.send(f"⚠️ Цвет не найден, используем **{DEFAULT_COLOR}** по умолчанию.")
    except asyncio.TimeoutError:
        pass

    ci = COLORS[color]
    await dm.send(embed=disnake.Embed(
        title="✅ Гильдия будет создана!",
        description=(
            f"> **Название:** {name}\n"
            f"> **Тег:** [{tag}]\n"
            f"> **Описание:** _{desc}_\n"
            f"> **Цвет:** {ci['label']}\n"
            "> _ _\n> Возвращайся на сервер! 🎉"
        ), color=ci["hex"]
    ).set_author(name=EMBED_AUTHOR))

    return {"name": name, "tag": tag, "desc": desc, "color": color}


# ══════════════════════════════════════════════════════════════
#   📦  ХРАНИЛИЩЕ СОСТОЯНИЙ ДЛЯ ПАГИНАЦИИ
# ══════════════════════════════════════════════════════════════
# Словарь: key -> список страниц (строк)
_page_store: dict = {}


# ══════════════════════════════════════════════════════════════
#   🤖  КОГ
# ══════════════════════════════════════════════════════════════

def apply_rank_bonuses(xp: int, coins: int, rank: str) -> tuple:
    """Применить бонусы XP/монет на основе ранга"""
    rank_data = GUILD_RANKS.get(rank, GUILD_RANKS["member"])
    return int(xp * rank_data["xp_bonus"]), int(coins * rank_data["coin_bonus"])

def can_user_action(rank: str, action: str) -> bool:
    """Проверить, может ли пользователь выполнить действие"""
    rank_data = GUILD_RANKS.get(rank, GUILD_RANKS["member"])
    action_key = f"can_{action}"
    return rank_data.get(action_key, False)

def is_admin():
    async def predicate(ctx):
        return ctx.author.id == 1187841298007330836
    return commands.check(predicate)

class GuildCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot   = bot
        self._xpcd: dict = {}
        if not self.season_task.is_running():
            self.season_task.start()

    def cog_unload(self):
        self.season_task.cancel()

    # ══════════════════════════════════════════════════════════
    #   📨  XP + МОНЕТЫ ЗА СООБЩЕНИЯ
    # ══════════════════════════════════════════════════════════

    @commands.Cog.listener()
    async def on_message(self, msg: disnake.Message):
        if msg.author.bot or not msg.guild:
            return
        uid, sid = str(msg.author.id), str(msg.guild.id)
        now = datetime.utcnow()
        key = f"{sid}:{uid}"

        last = self._xpcd.get(key)
        if last and (now - last).total_seconds() < XP_COOLDOWN_SEC:
            return
        self._xpcd[key] = now

        u       = get_user(uid, sid)
        old_lvl = u["level"]
        
        # Применяем бонусы ранга
        base_xp, base_coins = XP_PER_MSG, COINS_PER_MSG
        rank = u.get("guild_rank", "member")
        bonus_xp, bonus_coins = apply_rank_bonuses(base_xp, base_coins, rank)
        
        new_xp  = u["xp"] + bonus_xp
        new_lvl = calc_level(new_xp)
        new_co  = u["coins"] + bonus_coins
        new_msg = u["messages"] + 1

        save_user(uid, sid, {
            "xp": new_xp, "level": new_lvl,
            "coins": new_co, "messages": new_msg,
            "last_xp": now.isoformat(),
        })

        if new_lvl > old_lvl:
            bonus = new_lvl * 50
            save_user(uid, sid, {"coins": new_co + bonus})
            try:
                await msg.channel.send(
                    embed=ce("⬆️ Level Up!",
                        f"> {msg.author.mention} достиг **{new_lvl} уровня**! 🎉\n"
                        f"> 🎁 Бонус: **+{bonus} монет**",
                        msg.guild),
                    delete_after=12
                )
            except Exception:
                pass

    # ══════════════════════════════════════════════════════════
    #   🔘  КОМПОНЕНТЫ V1 — ОБРАБОТЧИК
    # ══════════════════════════════════════════════════════════

    @commands.Cog.listener()
    async def on_message_interaction(self, i: disnake.MessageInteraction):
        cid = i.data.custom_id

        # ── Invite ────────────────────────────────────────────
        if cid.startswith("invite:"):
            parts      = cid.split(":")
            action     = parts[1]
            gid        = parts[2]
            inviter_id = int(parts[3])
            invited_id = int(parts[4])

            if i.user.id != invited_id:
                await i.response.send_message("❌ Это не твоё приглашение!", ephemeral=True)
                return

            gd  = get_guild(gid)

            # Инвайт может прийти из ЛС — тогда i.guild is None
            # Получаем guild через bot
            guild = i.guild
            if guild is None and gd:
                guild = self.bot.get_guild(int(gd["server_id"]))

            if guild is None or not gd:
                await i.response.edit_message(
                    content="❌ Ошибка: сервер или гильдия не найдены.",
                    embed=None, components=[],
                )
                return

            sid = str(guild.id)

            dis_row = disabled_row(
                ("✅ Принять", disnake.ButtonStyle.success),
                ("❌ Отклонить", disnake.ButtonStyle.danger),
            )

            if action == "decline":
                await i.response.edit_message(
                    embed=ce("Приглашение",
                        f"> ❌ **{i.user.mention}** отклонил(а) приглашение.",
                        guild, 0xFF4444),
                    components=[dis_row],
                )
                return

            if action == "accept":
                u   = get_user(str(invited_id), sid)
                if u.get("guild_id"):
                    await i.response.edit_message(
                        embed=ce("Приглашение", "> **❌ Ты уже в гильдии!**", guild, 0xFF0000),
                        components=[dis_row],
                    )
                    return

                cnt   = member_count(gid, sid)
                limit = member_limit(gd.get("upgrades", []))
                if cnt >= limit:
                    await i.response.edit_message(
                        embed=ce("Приглашение", f"> **❌ Гильдия заполнена!** ({cnt}/{limit})", guild, 0xFF0000),
                        components=[dis_row],
                    )
                    return

                invited = guild.get_member(invited_id)
                save_user(str(invited_id), sid, {"guild_id": gid, "guild_rank": "member"})
                if invited:
                    await refresh_access(guild, gd, invited)
                    try:
                        old = invited.display_name
                        if old.startswith("[") and "]" in old:
                            old = old.split("]", 1)[1].strip()
                        await invited.edit(nick=f"[{gd['tag']}] {old}"[:32])
                    except Exception:
                        pass

                await i.response.edit_message(
                    embed=ge("🌸 Вступление в гильдию",
                        f"> ✅ **{i.user.mention}** вступил(а) в **[{gd['tag']}] {gd['name']}**! 🎉",
                        gd, guild),
                    components=[dis_row],
                )

        # ── Pagination ────────────────────────────────────────
        elif cid.startswith("page:"):
            parts    = cid.split(":")
            action   = parts[1]
            owner_id = int(parts[2])
            page     = int(parts[3])
            total    = int(parts[4])
            key      = parts[5]

            if i.user.id != owner_id:
                await i.response.send_message("❌ Это не твой список!", ephemeral=True)
                return

            page = page - 1 if action == "prev" else page + 1
            page = max(0, min(page, total - 1))

            pages = _page_store.get(key, [])
            if not pages:
                await i.response.send_message("❌ Данные устарели, повтори команду.", ephemeral=True)
                return

            title_fmt = _page_store.get(key + ":title", "📋 ({}/{})")
            new_row   = page_row(owner_id, page, total, key)
            await i.response.edit_message(
                embed=ce(title_fmt.format(page + 1, total), pages[page], i.guild),
                components=[new_row],
            )

        # ── Season claim ──────────────────────────────────────
        elif cid.startswith("season:claim:"):
            parts  = cid.split(":")
            uid    = str(parts[2])
            season = parts[3]

            if str(i.user.id) != uid:
                await i.response.send_message("❌ Это не твои задания!", ephemeral=True)
                return

            sid = str(i.guild.id)
            u   = get_user(uid, sid)
            pr  = u.get("event_progress", {})
            cl  = u.get("event_claimed", [])

            task_list = WINTER_TASKS if season == "winter" else SPRING_TASKS
            earned, total_coins = [], 0

            for t in task_list:
                if t["id"] in cl:
                    continue
                if pr.get(t["id"], 0) >= t["goal"]:
                    cl.append(t["id"])
                    total_coins += t["reward"]
                    earned.append(f"> {t['emoji']} **{t['name']}** → +{t['reward']:,} монет")

            if not earned:
                await i.response.send_message(
                    embed=ce("Ивент", "> **❌ Нет завершённых заданий для получения!**", i.guild, 0xFF4444),
                    ephemeral=True,
                )
                return

            save_user(uid, sid, {"event_claimed": cl, "coins": u["coins"] + total_coins})
            await i.response.send_message(
                embed=ce("🌸 Награды получены!",
                    "> _ _\n" + "\n".join(earned) + f"\n> _ _\n> **Итого:** +{total_coins:,} монет",
                    i.guild),
                ephemeral=True,
            )

        # ── Disabled noop ─────────────────────────────────────
        elif cid.startswith("disabled_noop"):
            await i.response.defer()

    # ══════════════════════════════════════════════════════════
    #   💰  ЭКОНОМИКА
    # ══════════════════════════════════════════════════════════

    @commands.command(name="profile", aliases=["prof"])
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def profile(self, ctx: commands.Context, member: disnake.Member = None):
        """Профиль игрока"""
        target   = member or ctx.author
        uid, sid = str(target.id), str(ctx.guild.id)
        u        = get_user(uid, sid)

        lvl  = u.get("level", 1)
        xp   = u.get("xp", 0)
        nxt  = xp_needed(xp, lvl)
        cur  = xp - LEVELS.get(lvl, 0)
        goal = (LEVELS.get(lvl + 1, LEVELS[MAX_LEVEL]) - LEVELS.get(lvl, 0)) if lvl < MAX_LEVEL else 1
        bar  = pbar(cur, goal)

        g_line = "—"
        if u.get("guild_id"):
            gd = get_guild(u["guild_id"])
            if gd:
                g_line = f"[{gd['tag']}] {gd['name']}"

        msg_req = get_msg_required(sid)
        msg_line = ""
        if not u.get("guild_id") and u.get("messages", 0) < msg_req:
            need = msg_req - u.get("messages", 0)
            mb   = pbar(u.get("messages", 0), msg_req)
            msg_line = (
                f"> _ _\n"
                f"> **📋 До создания гильдии:**\n"
                f"> [{mb}] {u.get('messages',0)}/{msg_req} сообщений\n"
                f"> Осталось: **{need}** сообщений"
            )

        desc = (
            f"> **⭐ Уровень:** {lvl} / {MAX_LEVEL}\n"
            f"> **✨ XP:** {xp:,}  _(до {lvl+1} лвл: {nxt:,} xp)_\n"
            f"> [{bar}]\n"
            f"> _ _\n"
            f"> **💰 Монеты:** {u.get('coins',0):,}\n"
            f"> **💬 Сообщений:** {u.get('messages',0):,}\n"
            f"> _ _\n"
            f"> **🏰 Гильдия:** {g_line}\n"
            f"> **🎖️ Ранг:** {rank_icon(u.get('guild_rank',''))} {(u.get('guild_rank') or '—').capitalize()}"
            f"{msg_line}"
        )
        e = ce(f"👤 {target.display_name}", desc, ctx.guild)
        if target.display_avatar:
            e.set_thumbnail(url=target.display_avatar.url)
        await ctx.send(embed=e)

    @commands.command(name="balance", aliases=["bal", "coins"])
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def balance(self, ctx: commands.Context, member: disnake.Member = None):
        """Баланс монет"""
        t = member or ctx.author
        u = get_user(str(t.id), str(ctx.guild.id))
        await ctx.send(embed=ce("💰 Баланс",
            f"> **{t.display_name}**\n> _ _\n"
            f"> 💰 **{u.get('coins',0):,}** монет\n"
            f"> ⭐ **{u.get('xp',0):,}** XP  (уровень {u.get('level',1)})\n"
            f"> 💬 **{u.get('messages',0):,}** сообщений",
            ctx.guild))

    @commands.command(name="daily")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def daily(self, ctx: commands.Context):
        """Ежедневный бонус"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u   = get_user(uid, sid)
        now = datetime.utcnow()

        if u.get("daily_last"):
            try:
                diff = now - datetime.fromisoformat(u["daily_last"])
                if diff.total_seconds() < DAILY_COOLDOWN_H * 3600:
                    rem = timedelta(hours=DAILY_COOLDOWN_H) - diff
                    h   = int(rem.total_seconds() // 3600)
                    m   = int((rem.total_seconds() % 3600) // 60)
                    await ctx.send(embed=ce("Daily",
                        f"> ⏰ Уже получил!\n> Следующий через: **{h}ч {m}м**", ctx.guild, 0xFF8800))
                    return
            except: pass

        bonus  = DAILY_COINS + random.randint(0, 100)
        new_co = u.get("coins", 0) + bonus
        save_user(uid, sid, {"coins": new_co, "daily_last": now.isoformat()})
        await ctx.send(embed=ce("🎁 Daily Bonus!",
            f"> {ctx.author.mention} получил ежедневный бонус!\n> _ _\n"
            f"> 💰 **+{bonus} монет**\n"
            f"> _ _\n> Баланс: **{new_co:,}**", ctx.guild))

    @commands.command(name="work")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def work(self, ctx: commands.Context):
        """Заработать монеты"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u   = get_user(uid, sid)
        now = datetime.utcnow()

        if u.get("work_last"):
            try:
                diff = now - datetime.fromisoformat(u["work_last"])
                if diff.total_seconds() < WORK_COOLDOWN_MIN * 60:
                    rem = timedelta(minutes=WORK_COOLDOWN_MIN) - diff
                    m   = int(rem.total_seconds() // 60)
                    await ctx.send(embed=ce("Работа",
                        f"> ⏰ Устал!\n> Отдохни ещё **{m} мин.**", ctx.guild, 0xFF8800))
                    return
            except: pass

        jobs = [
            ("🌸 Украсил парк цветами",      50, 150),
            ("🎨 Нарисовал картину",          80, 200),
            ("🧹 Навёл порядок в гильдии",    40, 120),
            ("🍰 Испёк торт для участников",  60, 180),
            ("🎵 Выступил на главной площади", 70, 160),
            ("📦 Развёз посылки по городу",   45, 130),
            ("🌿 Собрал урожай в саду",       55, 145),
            ("🔨 Починил забор у соседа",     35, 110),
            ("🐾 Выгулял питомцев",           30, 100),
            ("📚 Помог с уроками",            40, 120),
        ]
        job, mn, mx = random.choice(jobs)
        earned = random.randint(mn, mx)
        new_co = u.get("coins", 0) + earned
        save_user(uid, sid, {"coins": new_co, "work_last": now.isoformat()})
        await ctx.send(embed=ce("💼 Работа",
            f"> {job}\n> _ _\n> 💰 **+{earned} монет**\n> Баланс: **{new_co:,}**", ctx.guild))

    @commands.command(name="pay")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def pay(self, ctx: commands.Context, member: disnake.Member, amount: int):
        """Перевести монеты"""
        if member.id == ctx.author.id or member.bot:
            await ctx.send(embed=ce("Перевод", "> **❌ Нельзя!**", ctx.guild, 0xFF0000))
            return
        if amount <= 0:
            await ctx.send(embed=ce("Перевод", "> **❌ Сумма должна быть > 0**", ctx.guild, 0xFF0000))
            return

        uid, tid, sid = str(ctx.author.id), str(member.id), str(ctx.guild.id)
        u = get_user(uid, sid)
        if u.get("coins", 0) < amount:
            await ctx.send(embed=ce("Перевод",
                f"> **❌ Не хватает монет!**\n> У тебя: **{u.get('coins', 0):,}**", ctx.guild, 0xFF0000))
            return

        t = get_user(tid, sid)
        save_user(uid, sid, {"coins": u.get("coins", 0) - amount})
        save_user(tid, sid, {"coins": t.get("coins", 0) + amount})
        await ctx.send(embed=ce("💸 Перевод",
            f"> {ctx.author.mention} → {member.mention}\n> _ _\n> **{amount:,} монет**", ctx.guild))

    @commands.command(name="top", aliases=["leaderboard", "lb"])
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def top(self, ctx: commands.Context):
        """Топ игроков по XP"""
        sid = str(ctx.guild.id)
        # Получаем всех пользователей сервера из MongoDB
        try:
            us_docs = list(db["users"].find({"server_id": sid}).sort("xp", -1).limit(10))
        except Exception:
            us_docs = []
            
        medals = ["🥇", "🥈", "🥉"]
        desc = ""
        for i, u in enumerate(us_docs, 1):
            uid  = u["user_id"]
            mo   = ctx.guild.get_member(int(uid))
            name = mo.display_name if mo else f"ID:{uid}"
            med  = medals[i - 1] if i <= 3 else f"`#{i}`"
            desc += f"> {med} **{name}** — ⭐ {u['xp']:,} XP  💰 {u['coins']:,}\n"
        await ctx.send(embed=ce("🏆 Топ по XP", desc or "> Пока нет данных", ctx.guild))

    # ══════════════════════════════════════════════════════════
    #   🏰  ГИЛЬДИИ
    # ══════════════════════════════════════════════════════════

    @commands.command(name="gcreate")
    @commands.cooldown(*COOLDOWNS["guild_heavy"], commands.BucketType.user)
    async def gcreate(self, ctx: commands.Context):
        """Создать гильдию"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u        = get_user(uid, sid)
        msg_req  = get_msg_required(sid)

        if u.get("guild_id"):
            await ctx.send(embed=ce("Создание",
                "> **❌ Ты уже в гильдии!**\n> Выйди через `!gleave`", ctx.guild, 0xFF0000))
            return

        if u["messages"] < msg_req:
            need = msg_req - u["messages"]
            bar  = pbar(u["messages"], msg_req)
            await ctx.send(embed=ce("Создание Гильдии",
                f"> **❌ Недостаточно активности!**\n> _ _\n"
                f"> Нужно **{msg_req}** сообщений, у тебя **{u['messages']}**\n"
                f"> [{bar}] осталось **{need}** сообщений\n"
                f"> _ _\n> Пиши в чат и возвращайся! 💬",
                ctx.guild, 0xFF8800))
            return

        result = await creation_dialog(ctx, self.bot)
        if not result:
            return

        name, tag, desc, color = result["name"], result["tag"], result["desc"], result["color"]

        # Получаем список всех гильдий сервера
        try:
            gs = list(db["guilds"].find({"server_id": sid}))
        except Exception:
            gs = []
            
        for g in gs:
            if g.get("tag") == tag:
                await ctx.send(embed=ce("Создание",
                    f"> **❌ Тег [{tag}] уже занят!**", ctx.guild, 0xFF0000))
                return

        gid      = str(uuid.uuid4())[:8]
        cat, chs = await build_channels(ctx.guild, name, tag, color, ctx.author)

        save_guild(gid, {
            "id": gid, "server_id": sid,
            "name": name, "tag": tag, "description": desc, "color": color,
            "owner_id": uid, "officers": [], "upgrades": [],
            "bank": 0, "wins": 0, "losses": 0,
            "category_id": cat.id if cat else None,
            "channels": chs,
            "created_at": str(datetime.utcnow().date()),
        })
        save_user(uid, sid, {"guild_id": gid, "guild_rank": "owner"})

        try:
            old = ctx.author.display_name
            if old.startswith("[") and "]" in old:
                old = old.split("]", 1)[1].strip()
            await ctx.author.edit(nick=f"[{tag}] {old}"[:32])
        except Exception:
            pass

        ann_id = next((c["id"] for c in chs if c["slug"] == "анонсы"), None)
        if ann_id:
            ann_ch = ctx.guild.get_channel(ann_id)
            if ann_ch:
                try:
                    await ann_ch.send(embed=disnake.Embed(
                        title=f"🌸 Гильдия [{tag}] {name} основана!",
                        description=(
                            f"> **Лидер:** {ctx.author.mention}\n"
                            f"> **Описание:** _{desc}_\n> _ _\n"
                            f"> Пригласи участников: `!ginvite @юзер`"
                        ), color=chex(color)
                    ).set_author(name=EMBED_AUTHOR))
                except Exception:
                    pass

        await ctx.send(embed=ge("🏰 Гильдия создана!",
            f"> **[{tag}] {name}**\n> _{desc}_\n> _ _\n"
            f"> 👑 Лидер: {ctx.author.mention}\n"
            f"> 🎨 Цвет: {COLORS[color]['label']}\n"
            f"> 📁 Категория и каналы созданы!\n"
            f"> _ _\n> `!ginvite @юзер` — пригласить",
            get_guild(gid), ctx.guild))

    @commands.command(name="gdelete")
    @commands.cooldown(*COOLDOWNS["super_heavy"], commands.BucketType.user)
    async def gdelete(self, ctx: commands.Context):
        """Удалить гильдию (только лидер)"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Удаление", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if not gd or gd["owner_id"] != uid:
            await ctx.send(embed=ce("Удаление", "> **❌ Только лидер может удалить!**", ctx.guild, 0xFF0000))
            return

        await ctx.send(embed=ce("⚠️ Удаление",
            f"> Удалить **[{gd['tag']}] {gd['name']}**?\n"
            f"> Все участники будут исключены!\n> _ _\n"
            "> Напиши `ДА` для подтверждения (60 сек):",
            ctx.guild, 0xFF8800))

        def check(m):
            return m.author.id == ctx.author.id and m.channel.id == ctx.channel.id

        try:
            r = await self.bot.wait_for("message", check=check, timeout=60)
        except asyncio.TimeoutError:
            await ctx.send(embed=ce("Удаление", "> ⏰ Отменено.", ctx.guild, 0x888888))
            return
        if r.content.upper() != "ДА":
            await ctx.send(embed=ce("Удаление", "> ❌ Отменено.", ctx.guild, 0x888888))
            return

        try:
            if gd.get("category_id"):
                cat = ctx.guild.get_channel(int(gd["category_id"]))
                if cat:
                    for ch in list(cat.channels):
                        await ch.delete()
                    await cat.delete()
        except Exception:
            pass

        for md in guild_members(gid, sid):
            save_user(md.get("user_id") or md.get("uid"), sid, {"guild_id": None, "guild_rank": None})
            try:
                mo = ctx.guild.get_member(int(md.get("user_id") or md.get("uid")))
                if mo and mo.display_name.startswith("["):
                    clean = mo.display_name.split("]", 1)[1].strip()
                    await mo.edit(nick=clean or None)
            except Exception:
                pass

        db["guilds"].delete_one({"id": gid})
        await ctx.send(embed=ce("💔 Гильдия удалена",
            f"> **[{gd['tag']}] {gd['name']}** была распущена.", ctx.guild, 0x888888))

    @commands.command(name="greset")
    @is_admin()
    async def greset(self, ctx: commands.Context):
        """[ADMIN] Сбросить статистику всех игроков сервера"""
        sid = str(ctx.guild.id)
        try:
            us_list = list(db["users"].find({"server_id": sid}))
        except Exception:
            us_list = []
            
        for u in us_list:
            uid = u.get("user_id") or u.get("uid")
            if uid:
                save_user(uid, sid, {"messages": 0, "xp": 0, "level": 1, "coins": 0})
        
        await ctx.send(embed=ce("Admin", "🧹 Статистика всех игроков сброшена.", ctx.guild))

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot or not message.guild:
            return
            
        uid, sid = str(message.author.id), str(message.guild.id)
        u = get_user(uid, sid)
        
        # Экономика: XP и монеты
        now = datetime.utcnow()
        last_xp = u.get("last_xp")
        can_gain = True
        if last_xp:
            try:
                diff = now - datetime.fromisoformat(last_xp)
                if diff.total_seconds() < XP_COOLDOWN_SEC:
                    can_gain = False
            except: pass
            
        patch = {"messages": u.get("messages", 0) + 1}
        if can_gain:
            xp_gain = XP_PER_MSG
            coins_gain = COINS_PER_MSG
            
            # Бонусы рангов
            rank = u.get("guild_rank", "member")
            rank_data = GUILD_RANKS.get(rank, GUILD_RANKS["member"])
            xp_gain = int(xp_gain * rank_data.get("xp_bonus", 1.0))
            coins_gain = int(coins_gain * rank_data.get("coin_bonus", 1.0))
            
            new_xp = u.get("xp", 0) + xp_gain
            new_lvl = calc_level(new_xp)
            
            patch.update({
                "xp": new_xp,
                "coins": u.get("coins", 0) + coins_gain,
                "level": new_lvl,
                "last_xp": now.isoformat()
            })
            
            if new_lvl > u.get("level", 1):
                try:
                    await message.channel.send(
                        f"🎊 {message.author.mention}, новый уровень: **{new_lvl}**!",
                        delete_after=10
                    )
                except: pass
                
        save_user(uid, sid, patch)

    @commands.Cog.listener()
    async def on_interaction(self, inter: disnake.Interaction):
        if not inter.data or "custom_id" not in inter.data:
            return
        custom_id = inter.data["custom_id"]
        
        # Обработка инвайтов
        if custom_id.startswith("invite:"):
            # invite:accept/decline:gid:inviter_id:invited_id
            parts = custom_id.split(":")
            if len(parts) < 5: return
            action, gid, inviter_id, invited_id = parts[1], parts[2], parts[3], parts[4]
            
            if str(inter.author.id) != invited_id:
                await inter.response.send_message("> **❌ Это не твой инвайт!**", ephemeral=True)
                return
            
            gd = get_guild(gid)
            if not gd:
                await inter.response.edit_message(content="> **❌ Гильдия больше не существует.**", embed=None, components=[])
                return
                
            if action == "decline":
                await inter.response.edit_message(content=f"> **❌ {inter.author.mention} отклонил(а) приглашение.**", embed=None, components=[])
                return
                
            # Принятие
            sid = str(inter.guild.id)
            u = get_user(invited_id, sid)
            if u.get("guild_id"):
                await inter.response.send_message("> **❌ Ты уже в гильдии!**", ephemeral=True)
                return
                
            cnt = member_count(gid, sid)
            limit = member_limit(gd.get("upgrades", []))
            if cnt >= limit:
                await inter.response.send_message("> **❌ Гильдия заполнена!**", ephemeral=True)
                return
                
            save_user(invited_id, sid, {"guild_id": gid, "guild_rank": "member"})
            await refresh_access(inter.guild, gd, inter.author)
            
            try:
                old = inter.author.display_name
                if old.startswith("[") and "]" in old:
                    old = old.split("]", 1)[1].strip()
                await inter.author.edit(nick=f"[{gd['tag']}] {old}"[:32])
            except: pass
            
            await inter.response.edit_message(
                content=f"> **✅ {inter.author.mention} вступил(а) в гильдию [{gd['tag']}] {gd['name']}!**",
                embed=None, components=[]
            )
            
        # Обработка пагинации
        elif custom_id.startswith("page:"):
            # page:prev/next:owner_id:page:total:key
            parts = custom_id.split(":")
            if len(parts) < 6: return
            action, owner_id, page, total, pkey = parts[1], parts[2], int(parts[3]), int(parts[4]), parts[5]
            
            if str(inter.author.id) != owner_id:
                await inter.response.send_message("> **❌ Ты не можешь это переключать!**", ephemeral=True)
                return
                
            new_page = page - 1 if action == "prev" else page + 1
            if new_page < 0 or new_page >= total: return
            
            pages = _page_store.get(pkey)
            title_tpl = _page_store.get(pkey + ":title", "Страница {}/{}")
            if not pages:
                await inter.response.send_message("> **❌ Данные устарели. Повтори команду.**", ephemeral=True)
                return
                
            embed = ce(title_tpl.format(new_page + 1, total), pages[new_page], inter.guild)
            row = page_row(int(owner_id), new_page, total, pkey)
            await inter.response.edit_message(embed=embed, components=[row])
        
        # Обработка инвайтов
        if custom_id.startswith("invite:"):
            # invite:accept/decline:gid:inviter_id:invited_id
            parts = custom_id.split(":")
            if len(parts) < 5: return
            action, gid, inviter_id, invited_id = parts[1], parts[2], parts[3], parts[4]
            
            if str(inter.author.id) != invited_id:
                await inter.response.send_message("> **❌ Это не твой инвайт!**", ephemeral=True)
                return
            
            gd = get_guild(gid)
            if not gd:
                await inter.response.edit_message(content="> **❌ Гильдия больше не существует.**", embed=None, components=[])
                return
                
            if action == "decline":
                await inter.response.edit_message(content=f"> **❌ {inter.author.mention} отклонил(а) приглашение.**", embed=None, components=[])
                return
                
            # Принятие
            sid = str(inter.guild.id)
            u = get_user(invited_id, sid)
            if u.get("guild_id"):
                await inter.response.send_message("> **❌ Ты уже в гильдии!**", ephemeral=True)
                return
                
            cnt = member_count(gid, sid)
            limit = member_limit(gd.get("upgrades", []))
            if cnt >= limit:
                await inter.response.send_message("> **❌ Гильдия заполнена!**", ephemeral=True)
                return
                
            save_user(invited_id, sid, {"guild_id": gid, "guild_rank": "member"})
            await refresh_access(inter.guild, gd, inter.author)
            
            try:
                old = inter.author.display_name
                if old.startswith("[") and "]" in old:
                    old = old.split("]", 1)[1].strip()
                await inter.author.edit(nick=f"[{gd['tag']}] {old}"[:32])
            except: pass
            
            await inter.response.edit_message(
                content=f"> **✅ {inter.author.mention} вступил(а) в гильдию [{gd['tag']}] {gd['name']}!**",
                embed=None, components=[]
            )
            
        # Обработка пагинации
        elif custom_id.startswith("page:"):
            # page:prev/next:owner_id:page:total:key
            parts = custom_id.split(":")
            if len(parts) < 6: return
            action, owner_id, page, total, pkey = parts[1], parts[2], int(parts[3]), int(parts[4]), parts[5]
            
            if str(inter.author.id) != owner_id:
                await inter.response.send_message("> **❌ Ты не можешь это переключать!**", ephemeral=True)
                return
                
            new_page = page - 1 if action == "prev" else page + 1
            if new_page < 0 or new_page >= total: return
            
            pages = _page_store.get(pkey)
            title_tpl = _page_store.get(pkey + ":title", "Страница {}/{}")
            if not pages:
                await inter.response.send_message("> **❌ Данные устарели. Повтори команду.**", ephemeral=True)
                return
                
            embed = ce(title_tpl.format(new_page + 1, total), pages[new_page], inter.guild)
            row = page_row(int(owner_id), new_page, total, pkey)
            await inter.response.edit_message(embed=embed, components=[row])

    @commands.command(name="gtransfer")
    @commands.cooldown(*COOLDOWNS["super_heavy"], commands.BucketType.user)
    async def gtransfer(self, ctx: commands.Context, member: disnake.Member):
        """👑 Передать лидерство гильдии"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Передача", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd = get_guild(gid)
        if gd["owner_id"] != uid:
            await ctx.send(embed=ce("Передача", "> **❌ Только лидер может передать права!**", ctx.guild, 0xFF0000))
            return
        
        t_uid = str(member.id)
        t = get_user(t_uid, sid)
        if t.get("guild_id") != gid:
            await ctx.send(embed=ce("Передача", f"> **❌ {member.mention} не в твоей гильдии!**", ctx.guild, 0xFF0000))
            return
            
        if t_uid == uid:
            await ctx.send(embed=ce("Передача", "> **❌ Ты уже лидер!**", ctx.guild, 0xFF0000))
            return

        # Обновляем роли в базе
        save_user(uid, sid, {"guild_rank": "member"})
        save_user(t_uid, sid, {"guild_rank": "owner"})
        
        officers = gd.get("officers", [])
        if t_uid in officers:
            officers.remove(t_uid)
            
        save_guild(gid, {"owner_id": t_uid, "officers": officers})
        
        await ctx.send(embed=ge("👑 Лидерство передано", 
            f"> {ctx.author.mention} передал корону {member.mention}!", gd, ctx.guild))

    @commands.command(name="ginfo")
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def ginfo(self, ctx: commands.Context, *, tag: str = None):
        """Инфо о гильдии"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        if tag is None:
            u = get_user(uid, sid)
            if not u.get("guild_id"):
                await ctx.send(embed=ce("Гильдия", "> **❌ Укажи тег или вступи в гильдию!**", ctx.guild, 0xFF0000))
                return
            gd = get_guild(u["guild_id"])
        else:
            gd = guild_by_tag(sid, tag)
            
        if not gd:
            await ctx.send(embed=ce("Гильдия", "> **❌ Не найдено!**", ctx.guild, 0xFF0000))
            return

        owner = ctx.guild.get_member(int(gd["owner_id"]))
        o_name = owner.display_name if owner else f"ID:{gd['owner_id']}"
        ofr = ""
        for oid in gd.get("officers", [])[:5]:
            mo = ctx.guild.get_member(int(oid))
            if mo:
                ofr += f"> 🛡️ {mo.display_name}\n"
        ofr = ofr or "> —\n"
        
        cnt = member_count(gd["id"], sid)
        limit = member_limit(gd.get("upgrades", []))
        upg_str = ""
        for k in gd.get("upgrades", []):
            u_data = GUILD_UPGRADES.get(k)
            if u_data:
                upg_str += f"> {u_data['emoji']} {u_data['name']}\n"
        upg_str = upg_str or "> Нет апгрейдов\n"

        desc = (
            f"> **🌸 Название:** {gd['name']}\n"
            f"> **🏷️ Тег:** [{gd['tag']}]\n"
            f"> **📝 Описание:** _{gd['description']}_\n> _ _\n"
            f"> **👑 Лидер:** {o_name}\n"
            f"> **🛡️ Офицеры:**\n{ofr}> _ _\n"
            f"> **👥 Участников:** {cnt}/{limit}\n"
            f"> **💰 Казна:** {gd.get('bank',0):,} монет\n"
            f"> **⚔️ Бои:** {gd.get('wins',0)}W / {gd.get('losses',0)}L\n> _ _\n"
            f"> **🎨 Цвет:** {COLORS.get(gd['color'], COLORS[DEFAULT_COLOR])['label']}\n"
            f"> **⭐ Апгрейды:**\n{upg_str}"
            f"> 📅 Основана: {gd.get('created_at','?')}"
        )
        await ctx.send(embed=ge(f"🏰 [{gd['tag']}] {gd['name']}", desc, gd, ctx.guild))

    async def _send_invite(
        self,
        guild: disnake.Guild,
        inviter: disnake.Member,
        member: disnake.Member,
        respond_fn,          # async callable(embed, components, content) для ответа вызывающему
        error_fn,            # async callable(embed) для ошибок
    ):
        """Общая логика инвайта — используется и prefix, и slash командой."""
        uid, sid = str(inviter.id), str(guild.id)
        if member.bot or member.id == inviter.id:
            await error_fn(ce("Приглашение", "> **❌ Нельзя!**", guild, 0xFF0000))
            return
        u = get_user(uid, sid)
        if not u.get("guild_id"):
            await error_fn(ce("Приглашение", "> **❌ Ты не в гильдии!**", guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if not gd:
            return
        if uid != gd["owner_id"] and uid not in gd.get("officers", []):
            await error_fn(ce("Приглашение", "> **❌ Только лидер/офицеры приглашают!**", guild, 0xFF0000))
            return
        t = get_user(str(member.id), sid)
        if t.get("guild_id"):
            await error_fn(ce("Приглашение",
                f"> **❌ {member.display_name} уже в гильдии!**", guild, 0xFF0000))
            return
        cnt   = member_count(gid, sid)
        limit = member_limit(gd.get("upgrades", []))
        if cnt >= limit:
            await error_fn(ce("Приглашение",
                f"> **❌ Гильдия заполнена!** ({cnt}/{limit})\n> Купи апгрейд: `!gupgrade`",
                guild, 0xFF0000))
            return

        row = invite_row(gid, inviter.id, member.id)
        invite_embed = ge(
            f"🌸 Приглашение в [{gd['tag']}] {gd['name']}",
            f"> **{inviter.display_name}** приглашает тебя в гильдию!\n> _ _\n"
            f"> 📝 _{gd['description']}_\n"
            f"> 👥 {cnt}/{limit} участников\n> _ _\n"
            f"> Нажми кнопку ниже чтобы ответить!",
            gd, guild,
        )

        # Пробуем отправить в ЛС
        dm_sent = False
        try:
            dm = await member.create_dm()
            await dm.send(embed=invite_embed, components=[row])
            dm_sent = True
        except disnake.Forbidden:
            pass
        except Exception as e:
            print(f"[INVITE DM] {e}")

        # Всегда шлём в канал (упоминание + кнопки)
        # Если ЛС дошло — кнопки тоже в канале (дублируем для удобства)
        channel_note = "📬 Приглашение также отправлено в ЛС!" if dm_sent else "⚠️ ЛС закрыты — ответь здесь:"
        await respond_fn(
            content=member.mention,
            embed=ge(
                f"🌸 Приглашение в [{gd['tag']}] {gd['name']}",
                f"> {inviter.mention} приглашает {member.mention}!\n"
                f"> _{channel_note}_\n> _ _\n"
                f"> 📝 _{gd['description']}_\n"
                f"> 👥 {cnt}/{limit} участников\n> _ _\n"
                f"> У тебя **2 минуты** чтобы ответить!",
                gd, guild,
            ),
            components=[row],
        )

    @commands.command(name="ginvite")
    @commands.cooldown(*COOLDOWNS["guild_heavy"], commands.BucketType.user)
    async def ginvite(self, ctx: commands.Context, member: disnake.Member):
        """Пригласить участника в гильдию"""
        async def respond_fn(content, embed, components):
            await ctx.send(content=content, embed=embed, components=components)

        async def error_fn(embed):
            await ctx.send(embed=embed)

        await self._send_invite(ctx.guild, ctx.author, member, respond_fn, error_fn)

    @commands.slash_command(name="ginvite", description="Пригласить участника в гильдию")
    async def ginvite_slash(
        self,
        inter: disnake.ApplicationCommandInteraction,
        member: disnake.Member = commands.Param(description="Кого пригласить"),
    ):
        """Slash-версия: /ginvite @участник"""
        await inter.response.defer(ephemeral=False)

        async def respond_fn(content, embed, components):
            await inter.edit_original_response(content=content, embed=embed, components=components)

        async def error_fn(embed):
            await inter.edit_original_response(embed=embed)

        await self._send_invite(inter.guild, inter.author, member, respond_fn, error_fn)

    @commands.command(name="gleave")
    @commands.cooldown(*COOLDOWNS["guild_heavy"], commands.BucketType.user)
    async def gleave(self, ctx: commands.Context):
        """Покинуть гильдию"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Выход", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if not gd:
            return
        if gd["owner_id"] == uid:
            await ctx.send(embed=ce("Выход",
                "> **❌ Лидер не может просто уйти!**\n"
                "> `!gdelete` — удалить гильдию\n"
                "> `!gtransfer @юзер` — передать лидерство",
                ctx.guild, 0xFF0000))
            return
        if uid in gd.get("officers", []):
            gd["officers"].remove(uid)
            _dump(db)
        save_user(uid, sid, {"guild_id": None, "guild_rank": None})
        await refresh_access(ctx.guild, gd, ctx.author, remove=True)
        try:
            if ctx.author.display_name.startswith("["):
                clean = ctx.author.display_name.split("]", 1)[1].strip()
                await ctx.author.edit(nick=clean or None)
        except Exception:
            pass
        await ctx.send(embed=ce("👋 Выход",
            f"> {ctx.author.mention} покинул(а) **[{gd['tag']}] {gd['name']}**.", ctx.guild, 0x888888))

    @commands.command(name="gkick")
    @commands.cooldown(*COOLDOWNS["guild_heavy"], commands.BucketType.user)
    async def gkick(self, ctx: commands.Context, member: disnake.Member):
        """Кикнуть участника"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Кик", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if uid != gd["owner_id"] and uid not in gd.get("officers", []):
            await ctx.send(embed=ce("Кик", "> **❌ Нет прав!**", ctx.guild, 0xFF0000))
            return
        t_uid = str(member.id)
        t     = get_user(t_uid, sid)
        if t.get("guild_id") != gid:
            await ctx.send(embed=ce("Кик",
                f"> **❌ {member.display_name} не в твоей гильдии!**", ctx.guild, 0xFF0000))
            return
        if t_uid == gd["owner_id"]:
            await ctx.send(embed=ce("Кик", "> **❌ Нельзя кикнуть лидера!**", ctx.guild, 0xFF0000))
            return
        if t_uid in gd.get("officers", []):
            gd["officers"].remove(t_uid)
            _dump(db)
        save_user(t_uid, sid, {"guild_id": None, "guild_rank": None})
        await refresh_access(ctx.guild, gd, member, remove=True)
        try:
            if member.display_name.startswith("["):
                clean = member.display_name.split("]", 1)[1].strip()
                await member.edit(nick=clean or None)
        except Exception:
            pass
        await ctx.send(embed=ce("👢 Кик",
            f"> {member.mention} исключён(а) из **[{gd['tag']}]**.", ctx.guild, 0xFF4444))

    @commands.command(name="gpromote")
    @commands.cooldown(*COOLDOWNS["rank_ops"], commands.BucketType.user)
    async def gpromote(self, ctx: commands.Context, member: disnake.Member):
        """🔼 Повысить ранг участника (улучшенная система)"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Повышение", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        
        # Только лидер/вице-лидер могут повышать
        if u.get("guild_rank") not in ["owner", "viceowner"]:
            await ctx.send(embed=ce("Повышение", "> **❌ Только лидер или вице-лидер!**", ctx.guild, 0xFF0000))
            return
        
        t_uid = str(member.id)
        t     = get_user(t_uid, sid)
        if t.get("guild_id") != gid:
            await ctx.send(embed=ce("Повышение",
                f"> **❌ {member.display_name} не в вашей гильдии!**", ctx.guild, 0xFF0000))
            return
        
        current_rank = t.get("guild_rank", "recruit")
        rank_ladder = ["recruit", "member", "moderator", "officer", "viceowner", "owner"]
        
        if current_rank == "owner":
            await ctx.send(embed=ce("Повышение", "> **❌ Это максимальный ранг!**", ctx.guild, 0xFF0000))
            return
        
        if current_rank not in rank_ladder:
            current_rank = "recruit"
        
        idx = rank_ladder.index(current_rank)
        new_rank = rank_ladder[idx + 1] if idx + 1 < len(rank_ladder) else "owner"
        
        save_user(t_uid, sid, {"guild_rank": new_rank})
        
        rank_emoji = GUILD_RANKS[new_rank]["icon"]
        rank_name_str = GUILD_RANKS[new_rank]["name"]
        
        await ctx.send(embed=ge("🔼 Повышение ранга",
            f"> {member.mention} повышен(а) до **{rank_emoji} {rank_name_str}**!", gd, ctx.guild))

    @commands.command(name="gdemote")
    @commands.cooldown(*COOLDOWNS["rank_ops"], commands.BucketType.user)
    async def gdemote(self, ctx: commands.Context, member: disnake.Member):
        """🔽 Понизить ранг участника (улучшенная система)"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Понижение", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        
        # Только лидер/вице-лидер могут понижать
        if u.get("guild_rank") not in ["owner", "viceowner"]:
            await ctx.send(embed=ce("Понижение", "> **❌ Только лидер или вице-лидер!**", ctx.guild, 0xFF0000))
            return
        
        t_uid = str(member.id)
        t     = get_user(t_uid, sid)
        if t.get("guild_id") != gid:
            await ctx.send(embed=ce("Понижение",
                f"> **❌ {member.display_name} не в вашей гильдии!**", ctx.guild, 0xFF0000))
            return
        
        current_rank = t.get("guild_rank", "recruit")
        rank_ladder = ["recruit", "member", "moderator", "officer", "viceowner", "owner"]
        
        if current_rank == "recruit":
            await ctx.send(embed=ce("Понижение", "> **❌ Это уже минимальный ранг!**", ctx.guild, 0xFF0000))
            return
        
        if current_rank not in rank_ladder:
            current_rank = "member"
        
        idx = rank_ladder.index(current_rank)
        new_rank = rank_ladder[idx - 1] if idx > 0 else "recruit"
        
        save_user(t_uid, sid, {"guild_rank": new_rank})
        
        rank_emoji = GUILD_RANKS[new_rank]["icon"]
        rank_name_str = GUILD_RANKS[new_rank]["name"]
        
        await ctx.send(embed=ge("🔽 Понижение ранга",
            f"> {member.mention} понижен(а) до **{rank_emoji} {rank_name_str}**.", gd, ctx.guild))

    @commands.command(name="gtransfer")
    @commands.cooldown(*COOLDOWNS["super_heavy"], commands.BucketType.user)
    async def gtransfer(self, ctx: commands.Context, member: disnake.Member):
        """Передать лидерство"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Передача", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if gd["owner_id"] != uid:
            await ctx.send(embed=ce("Передача", "> **❌ Только лидер!**", ctx.guild, 0xFF0000))
            return
        t_uid = str(member.id)
        t     = get_user(t_uid, sid)
        if t.get("guild_id") != gid:
            await ctx.send(embed=ce("Передача",
                f"> **❌ {member.display_name} не в вашей гильдии!**", ctx.guild, 0xFF0000))
            return
        gd["owner_id"] = t_uid
        if t_uid in gd.get("officers", []):
            gd["officers"].remove(t_uid)
        _dump(db)
        save_user(uid, sid, {"guild_rank": "member"})
        save_user(t_uid, sid, {"guild_rank": "owner"})
        await ctx.send(embed=ge("👑 Передача лидерства",
            f"> {ctx.author.mention} передал(а) лидерство {member.mention}!\n"
            f"> Новый лидер **[{gd['tag']}]**: {member.mention}",
            gd, ctx.guild))

    @commands.command(name="granks")
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def granks(self, ctx: commands.Context):
        """📊 Показать все ранги гильдии с бонусами"""
        embed = ce("📊 Система Рангов",
            "Легенда всех доступных рангов в игре:",
            ctx.guild, 0x9370DB)
        
        for rank_key in ["recruit", "member", "moderator", "officer", "viceowner", "owner"]:
            if rank_key not in GUILD_RANKS:
                continue
            rd = GUILD_RANKS[rank_key]
            xp_bonus = f"{rd['xp_bonus']*100:.0f}%"
            coin_bonus = f"{rd['coin_bonus']*100:.0f}%"
            embed.add_field(
                name=f"{rd['icon']} {rd['name']}",
                value=f"XP: +{xp_bonus} | Монеты: +{coin_bonus}",
                inline=False
            )
        
        embed.set_footer(text="Ранги дают бонусы к получению XP и монет за сообщения!")
        await ctx.send(embed=embed)

    @commands.command(name="ginfo")
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def ginfo(self, ctx: commands.Context, *, tag: str = None):
        """Информация о гильдии"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        
        if tag is None:
            u  = get_user(uid, sid)
            if not u.get("guild_id"):
                await ctx.send(embed=ce("Гильдия",
                    "> **❌ Ты не в гильдии! Укажи тег: `!ginfo <тег>`**", ctx.guild, 0xFF0000))
                return
            gd = get_guild(u["guild_id"])
        else:
            gd = guild_by_tag(sid, tag)
        if not gd:
            await ctx.send(embed=ce("Гильдия", "> **❌ Не найдено!**", ctx.guild, 0xFF0000))
            return

        owner  = ctx.guild.get_member(int(gd["owner_id"]))
        o_name = owner.display_name if owner else f"ID:{gd['owner_id']}"
        ofr    = ""
        for oid in gd.get("officers", [])[:5]:
            mo = ctx.guild.get_member(int(oid))
            if mo:
                ofr += f"> 🛡️ {mo.display_name}\n"
        ofr   = ofr or "> —\n"
        cnt   = member_count(gd["id"], sid)
        limit = member_limit(gd.get("upgrades", []))
        upg   = ""
        for k in gd.get("upgrades", []):
            u_data = GUILD_UPGRADES.get(k)
            if u_data:
                upg += f"> {u_data['emoji']} {u_data['name']}\n"
        upg = upg or "> Нет апгрейдов\n"

        desc = (
            f"> **🌸 Название:** {gd['name']}\n"
            f"> **🏷️ Тег:** [{gd['tag']}]\n"
            f"> **📝 Описание:** _{gd['description']}_\n> _ _\n"
            f"> **👑 Лидер:** {o_name}\n"
            f"> **🛡️ Офицеры:**\n{ofr}> _ _\n"
            f"> **👥 Участников:** {cnt}/{limit}\n"
            f"> **💰 Казна:** {gd.get('bank',0):,} монет\n"
            f"> **⚔️ Бои:** {gd.get('wins',0)}W / {gd.get('losses',0)}L\n> _ _\n"
            f"> **🎨 Цвет:** {COLORS.get(gd['color'], COLORS[DEFAULT_COLOR])['label']}\n"
            f"> **⭐ Апгрейды:**\n{upg}"
            f"> 📅 Основана: {gd.get('created_at','?')}"
        )
        await ctx.send(embed=ge(f"🏰 [{gd['tag']}] {gd['name']}", desc, gd, ctx.guild))

    @commands.command(name="glist")
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def glist(self, ctx: commands.Context):
        """Список всех гильдий"""
        sid = str(ctx.guild.id)
        try:
            gs = list(db["guilds"].find({"server_id": sid}).sort("bank", -1))
        except Exception:
            gs = []
            
        if not gs:
            await ctx.send(embed=ce("Гильдии",
                "> **😢 Нет гильдий! Создай: `!gcreate`**", ctx.guild))
            return
        medals = ["🥇", "🥈", "🥉"]
        pages, per = [], 6
        for i in range(0, len(gs), per):
            chunk = gs[i:i + per]
            desc  = ""
            for j, g in enumerate(chunk, i + 1):
                med = medals[j - 1] if j <= 3 else f"`#{j}`"
                cnt = member_count(g["id"], sid)
                lim = member_limit(g.get("upgrades", []))
                em  = cat_em(g.get("color", DEFAULT_COLOR))
                desc += (
                    f"> {med} {em} **[{g['tag']}] {g['name']}**\n"
                    f"> 👥 {cnt}/{lim} | 💰 {g.get('bank',0):,} | ⚔️ {g.get('wins',0)}W\n> _ _\n"
                )
            pages.append(desc)

        total   = len(pages)
        pkey    = f"glist:{ctx.guild.id}:{ctx.author.id}:{int(datetime.utcnow().timestamp())}"
        _page_store[pkey]            = pages
        _page_store[pkey + ":title"] = "📋 Гильдии ({}/{})"

        row = page_row(ctx.author.id, 0, total, pkey)
        await ctx.send(
            embed=ce(f"📋 Гильдии (1/{total})", pages[0], ctx.guild),
            components=[row] if total > 1 else [],
        )

    @commands.command(name="gmembers")
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def gmembers(self, ctx: commands.Context, *, tag: str = None):
        """Участники гильдии"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        if tag is None:
            u  = get_user(uid, sid)
            if not u.get("guild_id"):
                await ctx.send(embed=ce("Участники",
                    "> **❌ Укажи тег!**", ctx.guild, 0xFF0000))
                return
            gd = get_guild(u["guild_id"])
        else:
            gd = guild_by_tag(sid, tag)
        if not gd:
            await ctx.send(embed=ce("Участники", "> **❌ Не найдено!**", ctx.guild, 0xFF0000))
            return

        mlist = guild_members(gd["id"], sid)
        desc  = ""
        for md in mlist:
            mid = md.get("user_id") or md.get("uid")
            mo   = ctx.guild.get_member(int(mid))
            name = mo.display_name if mo else f"ID:{mid}"
            desc += f"> {rank_icon(md.get('guild_rank','member'))} **{name}** — ⭐ {md['xp']:,} XP\n"
        cnt   = len(mlist)
        limit = member_limit(gd.get("upgrades", []))
        await ctx.send(embed=ge(
            f"👥 [{gd['tag']}] {gd['name']} ({cnt}/{limit})",
            desc or "> *Нет участников*", gd, ctx.guild
        ))

    @commands.command(name="gcolor")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def gcolor(self, ctx: commands.Context, color: str = None):
        """Сменить цвет гильдии"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Цвет", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if uid != gd["owner_id"] and uid not in gd.get("officers", []):
            await ctx.send(embed=ce("Цвет", "> **❌ Нет прав!**", ctx.guild, 0xFF0000))
            return
        if not color or color.lower() not in COLORS:
            avail = " | ".join(f"`{k}` {v['label']}" for k, v in COLORS.items())
            await ctx.send(embed=ce("🎨 Доступные цвета",
                f"> {avail}\n> _ _\n> `!gcolor <цвет>`", ctx.guild))
            return

        gd["color"] = color.lower()
        save_guild(gid, {"color": color.lower()})
        owner = ctx.guild.get_member(int(gd["owner_id"])) or ctx.author
        msg   = await ctx.send(embed=ce("⏳", "> Пересоздаю каналы с новым цветом...", ctx.guild))
        await rebuild(ctx.guild, gd, owner)
        ci = COLORS[color.lower()]
        await msg.edit(embed=ce("🎨 Цвет обновлён!",
            f"> **[{gd['tag']}]** → {ci['label']}\n> Каналы пересозданы!", ctx.guild, ci["hex"]))

    @commands.command(name="gdesc")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def gdesc(self, ctx: commands.Context, *, text: str):
        """Изменить описание гильдии"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Описание", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if uid != gd["owner_id"] and uid not in gd.get("officers", []):
            await ctx.send(embed=ce("Описание", "> **❌ Нет прав!**", ctx.guild, 0xFF0000))
            return
        if len(text) > 100:
            await ctx.send(embed=ce("Описание",
                "> **❌ Максимум 100 символов!**", ctx.guild, 0xFF0000))
            return
        gd["description"] = text
        save_guild(gid, {"description": text})
        await ctx.send(embed=ge("✏️ Описание обновлено", f"> _{text}_", gd, ctx.guild))

    @commands.command(name="gdeposit", aliases=["gdep"])
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def gdeposit(self, ctx: commands.Context, amount: int):
        """Внести монеты в казну"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Казна", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        if amount <= 0:
            await ctx.send(embed=ce("Казна", "> **❌ Сумма > 0**", ctx.guild, 0xFF0000))
            return
        if u["coins"] < amount:
            await ctx.send(embed=ce("Казна",
                f"> **❌ Не хватает монет!**\n> У тебя: {u['coins']:,}", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        new_bank = gd.get("bank", 0) + amount
        save_guild(gid, {"bank": new_bank})
        save_user(uid, sid, {"coins": u["coins"] - amount})
        gd["bank"] = new_bank
        await ctx.send(embed=ge("💰 Взнос в казну",
            f"> 💸 **+{amount:,} монет**\n> 🏦 Казна: **{new_bank:,}**", gd, ctx.guild))

    @commands.command(name="gwithdraw", aliases=["gwith"])
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def gwithdraw(self, ctx: commands.Context, amount: int):
        """Вывести монеты из казны (только лидер)"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Казна", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if gd["owner_id"] != uid:
            await ctx.send(embed=ce("Казна", "> **❌ Только лидер!**", ctx.guild, 0xFF0000))
            return
        if amount <= 0 or gd.get("bank", 0) < amount:
            await ctx.send(embed=ce("Казна",
                f"> **❌ Недостаточно в казне!**\n> В казне: {gd.get('bank',0):,}", ctx.guild, 0xFF0000))
            return
        new_bank = gd.get("bank", 0) - amount
        save_guild(gid, {"bank": new_bank})
        save_user(uid, sid, {"coins": u["coins"] + amount})
        gd["bank"] = new_bank
        await ctx.send(embed=ge("💸 Вывод из казны",
            f"> **-{amount:,}** из казны\n> Казна: **{new_bank:,}**", gd, ctx.guild))

    @commands.command(name="gupgrade")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def gupgrade(self, ctx: commands.Context, upg_id: str = None):
        """Апгрейды гильдии"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Апгрейды", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if not upg_id:
            desc = "> **Доступные апгрейды:**\n> _ _\n"
            for k, upg in GUILD_UPGRADES.items():
                owned = " ✅" if k in gd.get("upgrades", []) else ""
                desc += f"> {upg['emoji']} **{upg['name']}**{owned}  —  {upg['price']:,} монет  ID:`{k}`\n> _ _\n"
            desc += f"> 💰 **Казна:** {gd.get('bank',0):,}\n> Пример: `!gupgrade slot_1`"
            await ctx.send(embed=ge("⭐ Апгрейды", desc, gd, ctx.guild))
            return
        if uid != gd["owner_id"] and uid not in gd.get("officers", []):
            await ctx.send(embed=ce("Апгрейды", "> **❌ Нет прав!**", ctx.guild, 0xFF0000))
            return
        if upg_id not in GUILD_UPGRADES:
            await ctx.send(embed=ce("Апгрейды",
                f"> **❌ `{upg_id}` не найден!**", ctx.guild, 0xFF0000))
            return
        if upg_id in gd.get("upgrades", []):
            await ctx.send(embed=ce("Апгрейды", "> **❌ Уже куплен!**", ctx.guild, 0xFF0000))
            return
        upg  = GUILD_UPGRADES[upg_id]
        bank = gd.get("bank", 0)
        if bank < upg["price"]:
            await ctx.send(embed=ce("Апгрейды",
                f"> **❌ Не хватает!**\n> В казне: {bank:,} | Нужно: {upg['price']:,}",
                ctx.guild, 0xFF0000))
            return
        
        new_bank = bank - upg["price"]
        upgrades = gd.get("upgrades", [])
        upgrades.append(upg_id)
        
        save_guild(gid, {"bank": new_bank, "upgrades": upgrades})
        gd["bank"] = new_bank
        gd["upgrades"] = upgrades
        
        await ctx.send(embed=ge("⭐ Апгрейд куплен!",
            f"> {upg['emoji']} **{upg['name']}**\n> Казна: **{new_bank:,}**", gd, ctx.guild))

    @commands.command(name="gwar")
    @commands.cooldown(*COOLDOWNS["wars"], commands.BucketType.user)
    async def gwar(self, ctx: commands.Context, *, tag: str):
        """Война с другой гильдией"""
        uid, sid = str(ctx.author.id), str(ctx.guild.id)
        u  = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Война", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if gd["owner_id"] != uid:
            await ctx.send(embed=ce("Война",
                "> **❌ Только лидер объявляет войну!**", ctx.guild, 0xFF0000))
            return
        enemy = guild_by_tag(sid, tag)
        if not enemy:
            await ctx.send(embed=ce("Война",
                f"> **❌ Гильдия [{tag.upper()}] не найдена!**", ctx.guild, 0xFF0000))
            return
        if enemy["id"] == gid:
            await ctx.send(embed=ce("Война", "> **❌ Нельзя воевать с собой!**", ctx.guild, 0xFF0000))
            return

        my_p  = gd.get("bank", 0) + member_count(gid, sid) * 500 + random.randint(0, 3000)
        en_p  = enemy.get("bank", 0) + member_count(enemy["id"], sid) * 500 + random.randint(0, 3000)
        wmsg  = await ctx.send(embed=ce("⚔️ ВОЙНА ГИЛЬДИЙ!",
            f"> **[{gd['tag']}] {gd['name']}**\n> ⚔️ **VS** ⚔️\n"
            f"> **[{enemy['tag']}] {enemy['name']}**\n> _ _\n> Сражение начинается...",
            ctx.guild, 0xFF4444))
        await asyncio.sleep(3)

        winner, loser = (gd, enemy) if my_p > en_p else (enemy, gd)
        prize = min(loser.get("bank", 0) // 5, 10_000)
        
        # Обновляем победителя
        wr_upd = {
            "bank": winner.get("bank", 0) + prize,
            "wins": winner.get("wins", 0) + 1
        }
        save_guild(winner["id"], wr_upd)
        
        # Обновляем проигравшего
        lr_upd = {
            "bank": max(0, loser.get("bank", 0) - prize),
            "losses": loser.get("losses", 0) + 1
        }
        save_guild(loser["id"], lr_upd)
        
        # Чтения обновленные данные для отправки сообщения
        wr = get_guild(winner["id"])
        lr = get_guild(loser["id"])
        await wmsg.edit(embed=ce(
            f"🏆 ПОБЕДА: [{winner['tag']}] {winner['name']}!",
            f"> Разгромил **[{loser['tag']}]**!\n> _ _\n"
            f"> 💰 Трофей: **{prize:,} монет**!\n"
            f"> 🏆 [{winner['tag']}] Победы: {wr['wins']}\n"
            f"> 💀 [{loser['tag']}] Поражения: {lr['losses']}",
            ctx.guild, 0xFFD700))

    # ══════════════════════════════════════════════════════════
    #   👮  АДМИНСКИЕ КОМАНДЫ
    # ══════════════════════════════════════════════════════════

    @commands.command(name="grebuildall")
    @is_admin()
    async def grebuildall(self, ctx: commands.Context):
        """[ADMIN] Пересоздать каналы всех гильдий сервера"""
        sid = str(ctx.guild.id)
        try:
            gs_list = list(db["guilds"].find({"server_id": sid}))
        except Exception:
            gs_list = []
            
        msg = await ctx.send(embed=ce("⏳", f"> Пересоздаю каналы для {len(gs_list)} гильдий...", ctx.guild))
        
        for g in gs_list:
            gd = dict(g)
            owner = ctx.guild.get_member(int(gd["owner_id"])) or ctx.author
            await rebuild(ctx.guild, gd, owner)
            
        await msg.edit(embed=ce("✅ Готово!", f"> Каналы всех гильдий ({len(gs_list)}) пересозданы!", ctx.guild))

    @commands.command(name="gforcecolor")
    @is_admin()
    async def gforcecolor(self, ctx: commands.Context, tag: str, color: str):
        """[ADMIN] Принудительно сменить цвет + каналы гильдии"""
        sid = str(ctx.guild.id)
        gd  = guild_by_tag(sid, tag)
        if not gd:
            await ctx.send(embed=ce("Admin",
                f"> **❌ [{tag.upper()}] не найдена!**", ctx.guild, 0xFF0000))
            return
        if color.lower() not in COLORS:
            await ctx.send(embed=ce("Admin",
                f"> **❌ Цвет `{color}` не найден!**", ctx.guild, 0xFF0000))
            return
        gd["color"] = color.lower()
        owner = ctx.guild.get_member(int(gd["owner_id"])) or ctx.author
        msg   = await ctx.send(embed=ce("⏳",
            f"> Меняю цвет **[{gd['tag']}]** и пересоздаю каналы...", ctx.guild))
        await rebuild(ctx.guild, gd, owner)   # rebuild уже сохраняет в DB
        await msg.edit(embed=ce("✅ Готово!",
            f"> **[{gd['tag']}]** → {COLORS[color.lower()]['label']}!",
            ctx.guild, COLORS[color.lower()]["hex"]))

    @commands.command(name="gforcedelete")
    @is_admin()
    async def gforcedelete(self, ctx: commands.Context, *, tag: str):
        """[ADMIN] Принудительно удалить гильдию"""
        sid = str(ctx.guild.id)
        gd  = guild_by_tag(sid, tag)
        if not gd:
            await ctx.send(embed=ce("Admin",
                f"> **❌ [{tag.upper()}] не найдена!**", ctx.guild, 0xFF0000))
            return
        try:
            if gd.get("category_id"):
                cat = ctx.guild.get_channel(int(gd["category_id"]))
                if cat:
                    for ch in list(cat.channels):
                        await ch.delete()
                    await cat.delete()
        except Exception:
            pass
        for md in guild_members(gd["id"], sid):
            save_user(md["uid"], sid, {"guild_id": None, "guild_rank": None})
            try:
                mo = ctx.guild.get_member(int(md["uid"]))
                if mo and mo.display_name.startswith("["):
                    clean = mo.display_name.split("]", 1)[1].strip()
                    await mo.edit(nick=clean or None)
            except Exception:
                pass
        # Удаляем гильдию из MongoDB
        db["guilds"].delete_one({"id": gd["id"]})

    @commands.command(name="gforcekick")
    @is_admin()
    async def gforcekick(self, ctx: commands.Context, member: disnake.Member):
        """[ADMIN] Кикнуть из любой гильдии"""
        uid, sid = str(member.id), str(ctx.guild.id)
        u = get_user(uid, sid)
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Admin",
                f"> **❌ {member.display_name} не в гильдии!**", ctx.guild, 0xFF0000))
            return
        gid = u["guild_id"]
        gd  = get_guild(gid)
        if gd and uid in gd.get("officers", []):
            gd["officers"].remove(uid)
            _dump(db)
        save_user(uid, sid, {"guild_id": None, "guild_rank": None})
        if gd:
            await refresh_access(ctx.guild, gd, member, remove=True)
        try:
            if member.display_name.startswith("["):
                clean = member.display_name.split("]", 1)[1].strip()
                await member.edit(nick=clean or None)
        except Exception:
            pass
        await ctx.send(embed=ce("👢 Force Kick",
            f"> {member.mention} принудительно исключён(а).", ctx.guild, 0xFF4444))

    @commands.command(name="gforcejoin")
    @is_admin()
    async def gforcejoin(self, ctx: commands.Context, member: disnake.Member, *, tag: str):
        """[ADMIN] Принудительно добавить в гильдию"""
        uid, sid = str(member.id), str(ctx.guild.id)
        gd = guild_by_tag(sid, tag)
        if not gd:
            await ctx.send(embed=ce("Admin",
                f"> **❌ [{tag.upper()}] не найдена!**", ctx.guild, 0xFF0000))
            return
        u = get_user(uid, sid)
        if u.get("guild_id"):
            await ctx.send(embed=ce("Admin",
                f"> **❌ {member.display_name} уже в гильдии!**", ctx.guild, 0xFF0000))
            return
        save_user(uid, sid, {"guild_id": gd["id"], "guild_rank": "member"})
        await refresh_access(ctx.guild, gd, member)
        try:
            old = member.display_name
            if old.startswith("[") and "]" in old:
                old = old.split("]", 1)[1].strip()
            await member.edit(nick=f"[{gd['tag']}] {old}"[:32])
        except Exception:
            pass
        await ctx.send(embed=ce("✅ Force Join",
            f"> {member.mention} добавлен(а) в **[{gd['tag']}]**.", ctx.guild))

    @commands.command(name="gsetowner")
    @is_admin()
    async def gsetowner(self, ctx: commands.Context, member: disnake.Member, *, tag: str):
        """[ADMIN] Назначить нового лидера гильдии"""
        sid = str(ctx.guild.id)
        gd  = guild_by_tag(sid, tag)
        if not gd:
            await ctx.send(embed=ce("Admin",
                f"> **❌ [{tag.upper()}] не найдена!**", ctx.guild, 0xFF0000))
            return
        uid = str(member.id)
        t   = get_user(uid, sid)
        if t.get("guild_id") != gd["id"]:
            await ctx.send(embed=ce("Admin",
                f"> **❌ {member.display_name} не в этой гильдии!**", ctx.guild, 0xFF0000))
            return
        old_owner_id = gd.get("owner_id")
        if old_owner_id:
            save_user(str(old_owner_id), sid, {"guild_rank": "member"})
        
        # Обновляем гильдию - новый владелец и удаляем из officer если там
        officers = gd.get("officers", [])
        if uid in officers:
            officers.remove(uid)
        
        save_guild(gd["id"], {"owner_id": uid, "officers": officers})
        save_user(uid, sid, {"guild_rank": "owner"})
        await ctx.send(embed=ce("👑 Новый лидер",
            f"> {member.mention} теперь лидер **[{gd['tag']}]**.", ctx.guild))

    @commands.command(name="gaddbank")
    @is_admin()
    async def gaddbank(self, ctx: commands.Context, tag: str, amount: int):
        """[ADMIN] Добавить монеты в казну гильдии"""
        sid = str(ctx.guild.id)
        gd  = guild_by_tag(sid, tag)
        if not gd:
            await ctx.send(embed=ce("Admin",
                f"> **❌ [{tag.upper()}] не найдена!**", ctx.guild, 0xFF0000))
            return
        new_bank = gd.get("bank", 0) + amount
        save_guild(gd["id"], {"bank": new_bank})
        await ctx.send(embed=ce("💰 Казна пополнена",
            f"> **[{gd['tag']}]** +{amount:,} монет\n> Казна: **{db['guilds'][gd['id']]['bank']:,}**",
            ctx.guild))

    @commands.command(name="givemoney")
    @is_admin()
    async def givemoney(self, ctx: commands.Context, member: disnake.Member, amount: int):
        """[ADMIN] Выдать монеты игроку"""
        uid, sid = str(member.id), str(ctx.guild.id)
        u = get_user(uid, sid)
        save_user(uid, sid, {"coins": u["coins"] + amount})
        await ctx.send(embed=ce("💰 Выдача монет",
            f"> {member.mention} **+{amount:,} монет**\n> Баланс: **{u['coins']+amount:,}**", ctx.guild))

    @commands.command(name="takemoney")
    @is_admin()
    async def takemoney(self, ctx: commands.Context, member: disnake.Member, amount: int):
        """[ADMIN] Забрать монеты у игрока"""
        uid, sid = str(member.id), str(ctx.guild.id)
        u = get_user(uid, sid)
        new_co = max(0, u["coins"] - amount)
        save_user(uid, sid, {"coins": new_co})
        await ctx.send(embed=ce("Admin",
            f"> У {member.mention} изъято **{amount:,}** монет.\n> Баланс: **{new_co:,}**", ctx.guild))

    @commands.command(name="resetuser")
    @is_admin()
    async def resetuser(self, ctx: commands.Context, member: disnake.Member):
        """[ADMIN] Сбросить статистику игрока"""
        uid, sid = str(member.id), str(ctx.guild.id)
        # Удаляем из MongoDB
        db["users"].delete_one({"user_id": uid, "server_id": sid})
        await ctx.send(embed=ce("Admin", f"> Статистика {member.mention} сброшена.", ctx.guild))

    @commands.command(name="glistall")
    @is_admin()
    async def glistall(self, ctx: commands.Context):
        """[ADMIN] Список всех гильдий сервера (без пагинации)"""
        sid = str(ctx.guild.id)
        try:
            gs = list(db["guilds"].find({"server_id": sid}))
        except Exception:
            gs = []
        if not gs:
            await ctx.send("> Гильдий нет.")
            return
        desc = ""
        for g in gs:
            desc += f"> **[{g['tag']}] {g['name']}** (ID:{g['id']})\n"
        await ctx.send(embed=ce("Все гильдии", desc, ctx.guild))

    @commands.command(name="setmessages")
    @is_admin()
    async def setmessages(self, ctx: commands.Context, member: disnake.Member, amount: int):
        """[ADMIN] Установить кол-во сообщений игроку"""
        uid, sid = str(member.id), str(ctx.guild.id)
        save_user(uid, sid, {"messages": amount})
        await ctx.send(embed=ce("📝 Сообщения",
            f"> {member.mention}: **{amount:,}** сообщений", ctx.guild))

    @commands.command(name="setxp")
    @is_admin()
    async def setxp(self, ctx: commands.Context, member: disnake.Member, amount: int):
        """[ADMIN] Установить XP игроку"""
        uid, sid = str(member.id), str(ctx.guild.id)
        lvl = calc_level(amount)
        save_user(uid, sid, {"xp": amount, "level": lvl})
        await ctx.send(embed=ce("⭐ XP",
            f"> {member.mention}: **{amount:,}** XP | уровень **{lvl}**", ctx.guild))

    @commands.command(name="gcleardata")
    @is_admin()
    async def gcleardata(self, ctx: commands.Context, member: disnake.Member):
        """[ADMIN] Полный сброс данных игрока"""
        uid, sid = str(member.id), str(ctx.guild.id)
        db["users"].delete_one({"user_id": uid, "server_id": sid})
        await ctx.send(embed=ce("🗑️ Сброс",
            f"> Данные {member.mention} сброшены.", ctx.guild, 0xFF4444))

    @commands.command(name="gstats")
    @is_admin()
    async def gstats(self, ctx: commands.Context):
        """[ADMIN] Статистика бота"""
        sid = str(ctx.guild.id)
        try:
            gs_list = list(db["guilds"].find({"server_id": sid}))
            us_list = list(db["users"].find({"server_id": sid}))
        except Exception:
            gs_list, us_list = [], []
            
        await ctx.send(embed=ce("📊 Статистика",
            f"> 🏰 Гильдий: **{len(gs_list)}**\n"
            f"> 👤 Игроков: **{len(us_list)}**\n"
            f"> 💰 Монет: **{sum(u.get('coins',0) for u in us_list):,}**\n"
            f"> ⭐ Суммарный XP: **{sum(u.get('xp',0) for u in us_list):,}**\n"
            f"> 💬 Всего сообщений: **{sum(u.get('messages',0) for u in us_list):,}**\n"
            f"> 📁 DB: `MongoDB`",
            ctx.guild))

    @commands.command(name="gsetcalendar")
    @is_admin()
    async def gsetcalendar(self, ctx: commands.Context, channel: disnake.TextChannel):
        """[ADMIN] Канал для анонсов ивентов"""
        save_settings(str(ctx.guild.id), {SEASON_CH_KEY: channel.id})
        await ctx.send(embed=ce("✅ Установлено",
            f"> Анонсы сезонных ивентов → {channel.mention}", ctx.guild))

    @commands.command(name="gsetmsg")
    @is_admin()
    async def gsetmsg(self, ctx: commands.Context, amount: int):
        """[ADMIN] Изменить порог сообщений для создания гильдии"""
        save_settings(str(ctx.guild.id), {"msg_required": amount})
        await ctx.send(embed=ce("⚙️ Настройка",
            f"> Порог создания гильдии: **{amount}** сообщений", ctx.guild))

    # ══════════════════════════════════════════════════════════
    #   🌸❄️  ИВЕНТ
    # ══════════════════════════════════════════════════════════

    def _season(self) -> str:
        return "winter" if datetime.utcnow().month in [12, 1, 2] else "spring"

    def _stasks(self, s: str) -> list:
        return WINTER_TASKS if s == "winter" else SPRING_TASKS

    def _stitle(self, s: str) -> str:
        return "❄️ Конец Зимы" if s == "winter" else "🌸 Начало Весны"

    @commands.command(name="gseason")
    @commands.cooldown(*COOLDOWNS["info_light"], commands.BucketType.user)
    async def gseason(self, ctx: commands.Context):
        """Сезонный ивент — прогресс и задания"""
        uid, sid  = str(ctx.author.id), str(ctx.guild.id)
        s         = self._season()
        tasks     = self._stasks(s)
        title     = self._stitle(s)
        u         = get_user(uid, sid)
        pr        = u.get("event_progress", {})
        cl        = u.get("event_claimed", [])

        desc = f"> **Сезон: {title}**\n> _ _\n"
        for t in tasks:
            cur  = pr.get(t["id"], 0)
            goal = t["goal"]
            bar  = pbar(cur, goal)
            if t["id"] in cl:
                status = "✅ Получено"
            elif cur >= goal:
                status = "🟩 Готово! Нажми кнопку ↓"
            else:
                status = f"⏳ {cur}/{goal}"
            desc += (
                f"> {t['emoji']} **{t['name']}** — {status}\n"
                f"> _{t['desc']}_\n"
                f"> [{bar}]  💰 {t['reward']:,} монет\n> _ _\n"
            )

        col = 0x5BC8FF if s == "winter" else 0xFF69B4
        row = season_claim_row(ctx.author.id, s)
        await ctx.send(
            embed=ce(f"🎉 Ивент | {title}", desc, ctx.guild, col),
            components=[row],
        )

    async def _prog(self, uid: str, sid: str, task_id: str, n: int = 1):
        u  = get_user(uid, sid)
        pr = u.get("event_progress", {})
        tl = self._stasks(self._season())
        t  = next((x for x in tl if x["id"] == task_id), None)
        if t:
            pr[task_id] = min(pr.get(task_id, 0) + n, t["goal"])
            save_user(uid, sid, {"event_progress": pr})

    @commands.command(name="snowball")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def snowball(self, ctx: commands.Context, target: disnake.Member = None):
        await self._prog(str(ctx.author.id), str(ctx.guild.id), "wt_snow")
        t = f"в {target.mention}" if target else "в воздух"
        await ctx.send(embed=ce("❄️ Снежок!",
            f"> {ctx.author.mention} кинул снежок {t}! ❄️", ctx.guild, 0x5BC8FF))

    @commands.command(name="warm")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def warm(self, ctx: commands.Context, member: disnake.Member):
        if member.id == ctx.author.id:
            await ctx.send(embed=ce("Тепло", "> **❌ Нельзя себе!**", ctx.guild, 0xFF0000))
            return
        await self._prog(str(ctx.author.id), str(ctx.guild.id), "wt_warm")
        await ctx.send(embed=ce("🔥 Тепло!",
            f"> {ctx.author.mention} поделился теплом с {member.mention}! 🧣", ctx.guild, 0xFF8C00))

    @commands.command(name="snowman")
    @commands.cooldown(*COOLDOWNS["super_heavy"], commands.BucketType.user)
    async def snowman(self, ctx: commands.Context):
        await self._prog(str(ctx.author.id), str(ctx.guild.id), "wt_man")
        await ctx.send(embed=ce("⛄ Снеговик!",
            f"> {ctx.author.mention} слепил снеговика! ⛄🥕", ctx.guild, 0x5BC8FF))

    @commands.command(name="gpatrol")
    @commands.cooldown(*COOLDOWNS["wars"], commands.BucketType.user)
    async def gpatrol(self, ctx: commands.Context):
        u = get_user(str(ctx.author.id), str(ctx.guild.id))
        if not u.get("guild_id"):
            await ctx.send(embed=ce("Патруль", "> **❌ Ты не в гильдии!**", ctx.guild, 0xFF0000))
            return
        # Исправлено: task_id был "wt_patrol" — корректно для зимы
        await self._prog(str(ctx.author.id), str(ctx.guild.id), "wt_patrol")
        msg = random.choice([
            "🛡️ Враги разбежались!",
            "❄️ Патруль прошёл!",
            "⚔️ Граница под защитой!",
        ])
        await ctx.send(embed=ce("🛡️ Патруль!", f"> {msg}", ctx.guild, 0x4A90D9))

    @commands.command(name="flower")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def flower(self, ctx: commands.Context):
        await self._prog(str(ctx.author.id), str(ctx.guild.id), "sp_flower")
        f = random.choice(["🌸 Сакура", "🌷 Тюльпан", "🌺 Гибискус", "🌻 Подсолнух", "🌼 Ромашка"])
        await ctx.send(embed=ce("🌸 Сбор цветов!",
            f"> {ctx.author.mention} нашёл **{f}**!", ctx.guild, 0xFF69B4))

    @commands.command(name="plant")
    @commands.cooldown(*COOLDOWNS["eco_medium"], commands.BucketType.user)
    async def plant(self, ctx: commands.Context, member: disnake.Member):
        if member.id == ctx.author.id:
            await ctx.send(embed=ce("Посадка", "> **❌ Нельзя себе!**", ctx.guild, 0xFF0000))
            return
        await self._prog(str(ctx.author.id), str(ctx.guild.id), "sp_plant")
        await ctx.send(embed=ce("🌱 Посадка!",
            f"> {ctx.author.mention} посадил цветок для {member.mention}! 🌷", ctx.guild, 0x2ECC71))

    @commands.command(name="spring_rain")
    @commands.cooldown(*COOLDOWNS["super_heavy"], commands.BucketType.user)
    async def spring_rain(self, ctx: commands.Context):
        await self._prog(str(ctx.author.id), str(ctx.guild.id), "sp_rain")
        await ctx.send(embed=ce("🌧️ Весенний дождь!",
            f"> {ctx.author.mention} призвал весенний дождь! 🌧️🌸", ctx.guild, 0xFF69B4))

    @tasks.loop(hours=1)
    async def season_task(self):
        season = self._season()
        for srv in self.bot.guilds:
            sid = str(srv.id)
            st  = get_settings(sid)
            # Исправлено: проверяем last_season_date чтобы анонс шёл раз в сезон,
            # а не каждый рестарт
            if st.get("last_season") == season:
                continue
            ch_id = st.get(SEASON_CH_KEY)
            if not ch_id:
                continue
            ch = srv.get_channel(int(ch_id))
            if not ch:
                continue
            if season == "winter":
                title = "❄️ КОНЕЦ ЗИМЫ — Ивент начался!"
                col   = 0x5BC8FF
                desc  = (
                    "> Зима уходит! Успей выполнить:\n> _ _\n"
                    "> ❄️ `!snowball` — Кинь снежок\n"
                    "> 🔥 `!warm @` — Согрей друга\n"
                    "> ⛄ `!snowman` — Лепи снеговика\n"
                    "> 🛡️ `!gpatrol` — Патруль\n"
                    "> _ _\n> `!gseason` — прогресс 🎁"
                )
            else:
                title = "🌸 НАЧАЛО ВЕСНЫ — Ивент начался!"
                col   = 0xFF69B4
                desc  = (
                    "> Весна пришла в Sunshine Paradise!\n> _ _\n"
                    "> 🌸 `!flower` — Собери цветы\n"
                    "> 🌱 `!plant @` — Посади цветок\n"
                    "> 🌧️ `!spring_rain` — Призови дождь\n"
                    "> _ _\n> `!gseason` — прогресс 🎁"
                )
            try:
                await ch.send(embed=ce(title, desc, srv, col))
                save_settings(sid, {"last_season": season})
            except Exception as ex:
                print(f"[SEASON] {srv.name}: {ex}")

    @season_task.before_loop
    async def before_season(self):
        await self.bot.wait_until_ready()

    # ── Помощь ────────────────────────────────────────────────

    @commands.command(name="ghelp")
    async def ghelp(self, ctx: commands.Context):
        """Полная справка"""
        sid     = str(ctx.guild.id)
        msg_req = get_msg_required(sid)
        e = disnake.Embed(title="🌸 Sunshine Paradise — Справка", color=0xFF69B4)
        e.set_author(name=EMBED_AUTHOR, icon_url=ctx.guild.icon.url if ctx.guild.icon else None)
        e.add_field(name="💰 ЭКОНОМИКА", value=(
            "`!profile` `!balance` `!daily`\n`!work` `!pay @юзер сумма` `!top`"), inline=True)
        e.add_field(name="🏰 ГИЛЬДИИ", value=(
            f"`!gcreate` _(нужно {msg_req} msg)_\n`!gdelete` `!ginfo` `!glist`\n"
            "`!gmembers` `!ginvite @` `!gleave`"), inline=True)
        e.add_field(name="⚙️ УПРАВЛЕНИЕ", value=(
            "`!gkick @` `!gpromote @` `!gdemote @`\n`!gtransfer @` `!gcolor` `!gdesc`"), inline=True)
        e.add_field(name="💸 КАЗНА", value=(
            "`!gdeposit сумма` `!gwithdraw сумма`\n`!gupgrade [id]`"), inline=True)
        e.add_field(name="⚔️ БОЙ", value="`!gwar тег`", inline=True)
        e.add_field(name="🌸 ИВЕНТ", value=(
            "`!gseason`\n`!snowball` `!warm @` `!snowman`\n`!flower` `!plant @` `!spring_rain`"), inline=True)
        e.add_field(name="👮 ADMIN", value=(
            "`!grebuild тег` `!gforcecolor тег цвет`\n"
            "`!gforcedelete тег` `!gforcekick @`\n"
            "`!gforcejoin @ тег` `!gsetowner @ тег`\n"
            "`!gaddbank тег сумма` `!givemoney @ сумма`\n"
            "`!takemoney @ сумма` `!setmessages @ кол`\n"
            "`!setxp @ кол` `!gcleardata @`\n"
            "`!gstats` `!gsetcalendar #канал` `!gsetmsg кол`"), inline=False)
        clr_line = " ".join(f"`{k}`" for k in COLORS)
        e.add_field(name="🎨 ЦВЕТА", value=clr_line, inline=False)
        e.set_footer(text=f"Для создания гильдии нужно {msg_req} сообщений 💬")
        await ctx.send(embed=e)

    # ── Ошибки ────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_command_error(self, ctx: commands.Context, error):
        # Не перехватываем ошибки, которые уже обработаны в других когах
        if hasattr(ctx.command, "on_error"):
            return
        # Пробрасываем если у команды нет обработчика и ошибка не наша
        if ctx.cog is not self:
            return

        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(
                embed=ce("⏰ Кулдаун",
                    f"> Жди **{error.retry_after:.0f} сек**!", ctx.guild, 0xFF8800),
                delete_after=5,
            )
        elif isinstance(error, commands.CheckFailure):
            await ctx.send(
                embed=ce("❌", "> Доступ запрещен!", ctx.guild, 0xFF0000),
                delete_after=5,
            )
        elif isinstance(error, commands.MissingPermissions):
            await ctx.send(
                embed=ce("❌", "> Нет прав!", ctx.guild, 0xFF0000),
                delete_after=5,
            )
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send(
                embed=ce("❌", "> Пользователь не найден!", ctx.guild, 0xFF0000),
                delete_after=5,
            )
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(
                embed=ce("❌",
                    f"> Не хватает аргумента!\n> `!ghelp` — список команд", ctx.guild, 0xFF0000),
                delete_after=8,
            )
        elif isinstance(error, commands.CommandNotFound):
            pass
        else:
            print(f"[ERR] {ctx.command}: {error}")


# ══════════════════════════════════════════════════════════════
#   🔌  ПОДКЛЮЧЕНИЕ
# ══════════════════════════════════════════════════════════════

def setup(bot: commands.Bot):
    bot.add_cog(GuildCog(bot))
    print("✅  Sunshine Paradise — Guilds v4.0 загружен!")
    print(f"    �️  Database: MongoDB  |  🎨 Цветов: {len(COLORS)}  |  Components: V1")
